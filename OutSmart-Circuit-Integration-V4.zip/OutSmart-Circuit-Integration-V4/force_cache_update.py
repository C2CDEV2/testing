import sys
import os
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from app.driver_employee_cache import (
    fetch_circuit_drivers,
    fetch_outsmart_employees,
    save_cache_to_files,
    load_cache_from_files
)

def force_cache_update():
    """Force update the cache"""
    print("🔄 Forcing Cache Update")
    print("=" * 50)
    
    # Remove existing cache files
    import os
    cache_files = [
        "app/logs/drivers.json",
        "app/logs/employees.json", 
        "app/logs/cache_timestamp.txt"
    ]
    
    for file_path in cache_files:
        if os.path.exists(file_path):
            os.remove(file_path)
            print(f"🗑️ Removed {file_path}")
    
    # Fetch fresh data
    print("\n📥 Fetching fresh data...")
    drivers = fetch_circuit_drivers()
    employees = fetch_outsmart_employees()
    
    # Save to cache
    if drivers or employees:
        success = save_cache_to_files(drivers, employees)
        if success:
            print("\n✅ Cache updated successfully!")
        else:
            print("\n❌ Failed to save cache")
    else:
        print("\n❌ No data fetched")
    
    # Load and display cache
    print("\n📋 Current Cache Contents:")
    print("-" * 30)
    cached_drivers, cached_employees = load_cache_from_files()
    
    print(f"Drivers: {len(cached_drivers)}")
    for driver in cached_drivers[:3]:
        print(f"  - {driver.get('name')} (Email: {driver.get('email')})")
        print(f"    Depots: {driver.get('depots', [])}")
    
    print(f"\nEmployees: {len(cached_employees)}")
    for employee in cached_employees[:3]:
        print(f"  - {employee.get('firstname')} {employee.get('lastname')} (ID: {employee.get('number')})")

if __name__ == "__main__":
    force_cache_update()
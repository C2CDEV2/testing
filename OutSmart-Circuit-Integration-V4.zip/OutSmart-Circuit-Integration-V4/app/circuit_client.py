import httpx, os, json, time
from datetime import datetime, timedelta
from .config import CIRCUIT_BASE, CIRCUIT_API_KEY
from collections import deque

HEADERS = {"Authorization": f"Bearer {CIRCUIT_API_KEY}", "Content-Type": "application/json"}
LOG_DIR = "app/logs"
CIRCUIT_LOG = f"{LOG_DIR}/circuit_general.txt"
STOP_LOG = f"{LOG_DIR}/circuit_stops.txt"
PLAN_LOG = f"{LOG_DIR}/circuit_plans.txt"
OPTIMIZE_LOG = f"{LOG_DIR}/circuit_optimize.txt"
DISTRIBUTE_LOG = f"{LOG_DIR}/circuit_distribute.txt"
SKIPPED_STOP_LOG = f"{LOG_DIR}/circuit_skipped_stops.txt"

OPTIMIZE_RATE_LIMIT = 3
OPTIMIZE_WINDOW = 60
optimize_timestamps = deque(maxlen=OPTIMIZE_RATE_LIMIT)

_depot_name_cache = {}
_driver_name_cache = {}

def log_to_file(filepath, message: str, data: dict):
    try:
        os.makedirs(os.path.dirname(filepath), exist_ok=True)
        if os.path.exists(filepath) and os.path.getsize(filepath) > 10 * 1024 * 1024:
            backup_file = f"{filepath}.backup"
            if os.path.exists(backup_file):
                os.remove(backup_file)
            os.rename(filepath, backup_file)
        with open(filepath, "a", encoding="utf-8") as f:
            timestamp = datetime.now().isoformat()
            f.write(f"[{timestamp}] {message}: {json.dumps(data, ensure_ascii=False)}\n")
    except Exception as e:
        print(f"[⚠️] Error logging to {filepath}: {e}")

def log_circuit(message: str, data: dict):
    log_to_file(CIRCUIT_LOG, message, data)

def log_stop(message: str, data: dict):
    log_to_file(STOP_LOG, message, data)

def log_plan(message: str, data: dict):
    log_to_file(PLAN_LOG, message, data)

def log_optimize(message: str, data: dict):
    log_to_file(OPTIMIZE_LOG, message, data)

def log_distribute(message: str, data: dict):
    log_to_file(DISTRIBUTE_LOG, message, data)

def log_skipped_stop(message: str, data: dict):
    log_to_file(SKIPPED_STOP_LOG, message, data)

def throttle_optimization():
    try:
        now = time.time()
        if len(optimize_timestamps) >= OPTIMIZE_RATE_LIMIT:
            oldest_timestamp = optimize_timestamps[0]
            if now - oldest_timestamp < OPTIMIZE_WINDOW:
                sleep_time = OPTIMIZE_WINDOW - (now - oldest_timestamp) + 1
                print(f"[⏳] Rate limit: waiting {sleep_time:.1f} seconds before optimization")
                time.sleep(sleep_time)
        optimize_timestamps.append(now)
    except Exception as e:
        print(f"[⚠️] Error in optimization throttling: {e}")

def get_stoppage_time(depot_id, depot_name=None):
    global _depot_name_cache
    if depot_name:
        name_to_check = depot_name.lower()
    elif depot_id in _depot_name_cache:
        name_to_check = _depot_name_cache[depot_id].lower()
    else:
        try:
            res = httpx.get(f"{CIRCUIT_BASE}/depots", headers=HEADERS, timeout=30)
            res.raise_for_status()
            for depot in res.json().get("depots", []):
                if depot["id"] == depot_id:
                    _depot_name_cache[depot_id] = depot["name"]
                    name_to_check = depot["name"].lower()
                    break
            else:
                name_to_check = ""
        except Exception as e:
            log_circuit("Error fetching depot for stoppage time", {"depot_id": depot_id, "error": str(e)})
            name_to_check = ""
    # Lisboa: 2 min, Maia: 25 min, else default 12 min
    if "lisboa" in name_to_check:
        stoppage_seconds = 2 * 60
    elif "maia" in name_to_check:
        stoppage_seconds = 25 * 60
    else:
        stoppage_seconds = 12 * 60
    log_circuit("Stoppage time determined", {
        "depot_id": depot_id, 
        "depot_name": name_to_check, 
        "stoppage_minutes": stoppage_seconds // 60
    })
    return stoppage_seconds

def get_depot_name_by_id(depot_id):
    global _depot_name_cache
    if not depot_id:
        return None
    if depot_id in _depot_name_cache:
        return _depot_name_cache[depot_id]
    try:
        res = httpx.get(f"{CIRCUIT_BASE}/depots", headers=HEADERS, timeout=30)
        res.raise_for_status()
        for depot in res.json().get("depots", []):
            _depot_name_cache[depot["id"]] = depot["name"]
            if depot["id"] == depot_id:
                return depot["name"]
    except Exception as e:
        log_circuit("Error in get_depot_name_by_id", {"depot_id": depot_id, "error": str(e)})
    return None

def get_driver_name_by_id(driver_id):
    global _driver_name_cache
    if not driver_id:
        return None
    if driver_id in _driver_name_cache:
        return _driver_name_cache[driver_id]
    try:
        res = httpx.get(f"{CIRCUIT_BASE}/drivers?filter[active]=true&maxPageSize=50", headers=HEADERS, timeout=30)
        res.raise_for_status()
        for driver in res.json().get("drivers", []):
            _driver_name_cache[driver["id"]] = driver.get("name", "Unknown Driver")
            if driver["id"] == driver_id:
                return driver.get("name", "Unknown Driver")
    except Exception as e:
        log_circuit("Error in get_driver_name_by_id", {"driver_id": driver_id, "error": str(e)})
    return "Unknown Driver"

def get_or_create_driver_plan(work_date: str, driver_id: str, depot_id: str = None):
    try:
        dt = datetime.strptime(work_date, "%d-%m-%Y")
        cd = dt.strftime("%Y-%m-%d")
    except Exception:
        cd = datetime.now().strftime("%Y-%m-%d")
    existing_plans = []
    try:
        res = httpx.get(f"{CIRCUIT_BASE}/plans", headers=HEADERS, timeout=30)
        res.raise_for_status()
        existing_plans = res.json().get("plans", [])
    except Exception as e:
        log_circuit("Error fetching existing plans", {"error": str(e)})
        existing_plans = []
    matching_plan = None
    for plan in existing_plans:
        starts = plan.get("starts", {})
        plan_day = starts.get("day")
        plan_month = starts.get("month")
        plan_year = starts.get("year")
        plan_drivers = [d.get("id") if isinstance(d, dict) else d for d in plan.get("drivers", [])]
        try:
            target_dt = datetime.strptime(cd, "%Y-%m-%d")
            if (plan_day == target_dt.day and 
                plan_month == target_dt.month and 
                plan_year == target_dt.year and
                len(plan_drivers) == 1 and
                plan_drivers[0] == driver_id):
                if plan.get("distributed", False) or plan.get("locked", False):
                    continue
                matching_plan = plan
                break
        except Exception:
            continue
    if matching_plan:
        log_circuit("Found existing driver plan", {
            "plan_id": matching_plan["id"],
            "work_date": work_date,
            "driver_id": driver_id
        })
        return matching_plan["id"]
    try:
        target_dt = datetime.strptime(cd, "%Y-%m-%d")
        day_name = target_dt.strftime("%A")
    except Exception:
        day_name = "Unknown"
    driver_name = get_driver_name_by_id(driver_id) or "Unknown Driver"
    depot_name = get_depot_name_by_id(depot_id) or "Unknown Depot"
    plan_title = f"Driver: {driver_name} - {day_name}, {work_date} - {depot_name}"
    payload = {
        "title": plan_title,
        "starts": {
            "day": target_dt.day,
            "month": target_dt.month,
            "year": target_dt.year
        },
        "drivers": [driver_id]
    }
    if depot_id:
        payload["depot"] = depot_id
    try:
        res = httpx.post(f"{CIRCUIT_BASE}/plans", headers=HEADERS, json=payload, timeout=30)
        res.raise_for_status()
        new_plan = res.json()
        log_circuit("Created new driver plan", {
            "plan_id": new_plan["id"],
            "title": plan_title,
            "work_date": work_date,
            "driver_id": driver_id,
            "depot_id": depot_id
        })
        return new_plan["id"]
    except Exception as e:
        log_circuit("Error creating driver plan", {
            "work_date": work_date,
            "driver_id": driver_id,
            "depot_id": depot_id,
            "error": str(e)
        })
        return None

def optimize_plan(plan_id: str) -> dict:
    url = f"{CIRCUIT_BASE}/{plan_id}:optimize"
    payload = {}
    try:
        res = httpx.post(url, headers=HEADERS, json=payload, timeout=30.0)
        res.raise_for_status()
        optimization_data = res.json()
        log_optimize("Plan optimization started", {"plan_id": plan_id, "response": optimization_data})
        # Log skipped stops for debugging
        skipped_stops = optimization_data.get("result", {}).get("skippedStops", [])
        for stop in skipped_stops:
            log_skipped_stop("Skipped stop during optimization", stop)
        if optimization_data.get("id"):
            optimization_id = optimization_data["id"]
            return wait_for_optimization_completion(optimization_id)
        return {"success": True, "optimization": optimization_data}
    except httpx.HTTPStatusError as e:
        error_detail = {"status": e.response.status_code, "body": e.response.text, "plan_id": plan_id}
        log_optimize("Error optimizing plan", error_detail)
        if e.response.status_code == 429:
            log_circuit("Rate limit hit, waiting before retry", {"plan_id": plan_id})
            time.sleep(10)
            try:
                res_retry = httpx.post(url, headers=HEADERS, json=payload, timeout=30.0)
                res_retry.raise_for_status()
                optimization_data = res_retry.json()
                log_circuit("Plan optimization succeeded on retry", {"plan_id": plan_id})
                if optimization_data.get("id"):
                    return wait_for_optimization_completion(optimization_data["id"])
                return {"success": True, "optimization": optimization_data}
            except:
                return {"success": False, "error": "Rate limited", "retry_after": 10}
        if e.response.status_code == 409:
            response_text = e.response.text.lower()
            if "already optimized" in response_text or "optimization" in response_text:
                log_circuit("Plan already optimized", {"plan_id": plan_id})
                return {"success": True, "message": "Plan already optimized"}
        return {"success": False, "error": f"HTTP {e.response.status_code}: {e.response.text}"}
    except Exception as e:
        log_optimize("Error optimizing plan", {"plan_id": plan_id, "error": str(e)})
        return {"success": False, "error": str(e)}

def wait_for_optimization_completion(optimization_id: str, max_wait_time: int = 300) -> dict:
    start_time = time.time()
    while time.time() - start_time < max_wait_time:
        try:
            res = httpx.get(f"{CIRCUIT_BASE}/{optimization_id}", headers=HEADERS, timeout=30)
            res.raise_for_status()
            optimization_status = res.json()
            if optimization_status.get("done", False):
                log_circuit("Optimization completed", {"optimization_id": optimization_id, "result": optimization_status})
                return {"success": True, "optimization": optimization_status}
            log_circuit("Optimization in progress", {"optimization_id": optimization_id, "status": optimization_status.get("type", "unknown")})
            time.sleep(10)
        except Exception as e:
            log_circuit("Error checking optimization status", {"optimization_id": optimization_id, "error": str(e)})
            return {"success": False, "error": str(e)}
    log_circuit("Optimization timeout", {"optimization_id": optimization_id})
    return {"success": False, "error": "Optimization timeout"}

def distribute_plan(plan_id: str) -> dict:
    url = f"{CIRCUIT_BASE}/{plan_id}:distribute"
    try:
        plan_res = httpx.get(f"{CIRCUIT_BASE}/{plan_id}", headers=HEADERS, timeout=30)
        plan_res.raise_for_status()
        plan = plan_res.json()
        
        # Set fixed depot hours for all drivers
        drivers_payload = []
        for d in plan.get("drivers", []):
            driver_id = d.get("id") if isinstance(d, dict) else d
            if driver_id:
                drivers_payload.append({
                    "id": driver_id,
                    "routeOverrides": {
                        "startTime": {"hour": 9, "minute": 30},
                        "endTime": {"hour": 17, "minute": 30}
                    }
                })

        payload = {"drivers": drivers_payload} if drivers_payload else {}
        
        log_distribute("Setting fixed depot hours", {
            "plan_id": plan_id,
            "driver_hours": "09:30 - 17:30",
            "num_drivers": len(drivers_payload)
        })

        res = httpx.post(url, headers=HEADERS, json=payload, timeout=30.0)
        res.raise_for_status()
        distribution_result = res.json()
        
        log_distribute("Plan distributed", {
            "plan_id": plan_id, 
            "response": distribution_result
        })
        
        return {"success": True, "distribution": distribution_result}

    except httpx.HTTPStatusError as e:
        error_detail = {"status": e.response.status_code, "body": e.response.text, "plan_id": plan_id}
        log_distribute("Error distributing plan", error_detail)
        if e.response.status_code == 429:
            log_circuit("Rate limit hit on distribution", {"plan_id": plan_id})
            time.sleep(5)
            return {"success": False, "error": "Rate limited", "retry_after": 5}
        if e.response.status_code == 400:
            response_text = e.response.text.lower()
            if "already distributed" in response_text:
                return {"success": True, "message": "Plan already distributed"}
            elif "not yet optimized" in response_text:
                return {"success": False, "error": "Plan not yet optimized"}
        return {"success": False, "error": f"HTTP {e.response.status_code}: {e.response.text}"}
    except Exception as e:
        log_distribute("Error distributing plan", {"plan_id": plan_id, "error": str(e)})
        return {"success": False, "error": str(e)}

def process_plan_optimization_and_distribution(plan_id: str, max_retries: int = 3):
    try:
        res = httpx.get(f"{CIRCUIT_BASE}/{plan_id}", headers=HEADERS, timeout=30)
        res.raise_for_status()
        plan = res.json()
        if plan.get("locked", False):
            log_circuit("Plan is locked, skipping", {"plan_id": plan_id})
            return {"success": False, "error": "Plan is locked"}
        if plan.get("distributed", False):
            log_circuit("Plan already distributed", {"plan_id": plan_id})
            return {"success": True, "message": "Plan already distributed"}
        for attempt in range(max_retries):
            try:
                throttle_optimization()
                optimization_result = optimize_plan(plan_id)
                if not optimization_result.get("success"):
                    if "already optimized" in str(optimization_result.get("message", "")):
                        break
                    if attempt < max_retries - 1:
                        time.sleep(5)
                        continue
                    return optimization_result
                time.sleep(2)
                distribution_result = distribute_plan(plan_id)
                if distribution_result.get("success"):
                    return {"success": True, "optimization": optimization_result, "distribution": distribution_result}
                if "already distributed" in str(distribution_result.get("message", "")):
                    return {"success": True, "message": "Plan already distributed"}
                if attempt < max_retries - 1:
                    time.sleep(5)
                    continue
                return distribution_result
            except Exception as e:
                log_circuit("Error in optimization/distribution attempt", {"plan_id": plan_id, "attempt": attempt + 1, "error": str(e)})
                if attempt < max_retries - 1:
                    time.sleep(5)
                    continue
                return {"success": False, "error": str(e)}
        return {"success": False, "error": "Max retries exceeded"}
    except Exception as e:
        log_circuit("Unexpected error in optimization and distribution", {"plan_id": plan_id, "error": str(e)})
        return {"success": False, "error": "Unexpected error in optimization and distribution"}

def send_stop(order: dict) -> dict:
    if not order:
        return {"success": False, "error": "No order provided"}
    try:
        plan_id = order.get("force_plan_id")
        driver_id = order.get("force_driver_id")
        depot_id = order.get("force_depot_id")
        if not plan_id:
            return {"success": False, "error": "No plan_id provided"}
        customer_name = (order.get("CustomerName") or "").strip()
        street = (order.get("CustomerStreet") or "").strip()
        street_no = (order.get("CustomerStreetNo") or "").strip()
        city = (order.get("CustomerCity") or "").strip()
        line_one = " ".join([p for p in [street, street_no] if p]).strip()
        if not line_one:
            line_one = customer_name
        addr = {
            "addressName": customer_name,
            "addressLineOne": line_one,
        }
        if city:
            addr["city"] = city
        lat, lng = order.get("CustomerLatitude"), order.get("CustomerLongitude")
        if lat and lng:
            try:
                addr["latitude"] = float(lat)
                addr["longitude"] = float(lng)
            except Exception:
                log_circuit("Failed to parse coordinates", {"lat": lat, "lng": lng})
        recipient = {}
        for field, key in [
            ("id", "externalId"),
            ("CustomerEmail", "email"),
            ("CustomerPhone", "phone"),
            ("CustomerName", "name")
        ]:
            value = order.get(field, "")
            if value:
                recipient[key] = str(value)
        order_info = {}
        products = [m.get("MaterialName", "") for m in order.get("Materials", []) if m.get("MaterialName", "")]
        if products:
            order_info["products"] = products
        for field, key in [
            ("OrderNr", "sellerOrderId"),
            ("CustomerNameInvoice", "sellerName")
        ]:
            value = order.get(field, "")
            if value:
                order_info[key] = value
        def _parse_hm(val: str, default_h: int, default_m: int):
            try:
                h, m = map(int, (val or "").split(":"))
                return h, m
            except Exception:
                return default_h, default_m
        work_time = order.get("WorkTime", "")
        work_end_time = order.get("WorkEndTime", "")
        earliest_hour, earliest_min = _parse_hm(work_time, 9, 30)
        earliest_total_mins = max(9 * 60 + 30, earliest_hour * 60 + earliest_min)
        if work_end_time and work_end_time.strip():
            latest_hour, latest_min = _parse_hm(work_end_time, 17, 30)
            latest_total_mins = min(18 * 60, latest_hour * 60 + latest_min)
        else:
            latest_total_mins = min(18 * 60, earliest_total_mins + 120)
        # Ensure at least 30 min window
        latest_total_mins = max(earliest_total_mins + 30, latest_total_mins)
        earliest_hour, earliest_min = divmod(earliest_total_mins, 60)
        latest_hour, latest_min = divmod(latest_total_mins, 60)
        # Set fixed depot hours (09:30 - 17:30)
        depot_start_hour, depot_start_min = 9, 30
        depot_end_hour, depot_end_min = 17, 30
        # Calculate earliest time (never before depot start)
        earliest_hour = depot_start_hour
        earliest_min = depot_start_min
        earliest_total_mins = earliest_hour * 60 + earliest_min
        # Calculate latest time (never after depot end)
        latest_total_mins = depot_end_hour * 60 + depot_end_min
        # Always use depot default stop time
        estimated_attempt_duration = get_stoppage_time(depot_id)
        timing = {
            "earliestAttemptTime": {"hour": earliest_hour, "minute": earliest_min},
            "latestAttemptTime": {"hour": depot_end_hour, "minute": depot_end_min},
            "estimatedAttemptDuration": estimated_attempt_duration
        }
        log_stop("Stop timing created", {
            "order_id": order.get("id"),
            "customer_window": f"{work_time} - {work_end_time}",
            "delivery_window": f"{earliest_hour:02d}:{earliest_min:02d} - {depot_end_hour:02d}:{depot_end_min:02d}",
            "timing": timing,
            "duration_minutes": estimated_attempt_duration // 60
        })
        payload = {
            "address": addr,
            "timing": timing,
            "activity": "delivery",
            "packageCount": 1,
        }
        if driver_id:
            payload["allowedDrivers"] = [driver_id]
        if recipient:
            payload["recipient"] = recipient
        if order_info:
            payload["orderInfo"] = order_info
        notes_parts = []
        for note_field in ["CustomerRemark", "WorkDescription", "TypeOfWork"]:
            note_value = order.get(note_field, "")
            if note_value and note_value.strip():
                notes_parts.append(note_value.strip())
        if notes_parts:
            payload["notes"] = " | ".join(notes_parts)
        res = httpx.post(f"{CIRCUIT_BASE}/{plan_id}/stops", headers=HEADERS, json=payload, timeout=30)
        res.raise_for_status()
        stop_data = res.json()
        log_stop("Stop created", {
            "stop_id": stop_data.get("id"),
            "order_id": order.get("id"),
            "driver_id": driver_id,
            "plan_id": plan_id
        })
        return {
            "success": True, 
            "response": stop_data,
            "plan_id": plan_id,
            "driver_id": driver_id
        }
    except httpx.HTTPStatusError as e:
        log_stop("HTTP error creating stop", {"status": e.response.status_code, "body": e.response.text})
        return {"success": False, "error": f"HTTP {e.response.status_code}: {e.response.text}"}
    except Exception as e:
        log_stop("Error creating stop", {"error": str(e)})
        return {"success": False, "error": str(e)}
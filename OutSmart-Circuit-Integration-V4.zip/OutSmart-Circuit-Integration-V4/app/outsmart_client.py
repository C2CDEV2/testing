import httpx, os
from datetime import datetime, timedelta
from .config import OUTSMART_BASE_URL, OUTSMART_BEARER

HEADERS = {
    "Authorization": f"Bearer {OUTSMART_BEARER}",
    "Accept": "*/*"
}

LOG_FILE = "app/logs/outsmart_fetch.txt"

def log_fetch(latest_dt, orders):
    os.makedirs(os.path.dirname(LOG_FILE), exist_ok=True)
    with open(LOG_FILE, "a", encoding="utf-8") as f:
        f.write(f"[{datetime.now().isoformat()}] Latest Execution: {latest_dt.strftime('%d-%m-%Y %H:%M')}, "
                f"Orders: {len(orders)}, OrderNr: {[o.get('OrderNr') for o in orders]}\n")

def get_synced_workorder_ids():
    """Load already synced workorder IDs from file"""
    try:
        synced_file = "app/logs/synced_workorders.txt"
        if os.path.exists(synced_file):
            with open(synced_file, "r", encoding="utf-8") as f:
                synced_ids = set(line.strip() for line in f if line.strip())
                return synced_ids
        return set()
    except Exception as e:
        print(f"[⚠️] Error reading synced workorders: {e}")
        return set()

def print_order_analytics(raw_count, valid_count, synced_count, new_count, skipped_reasons, status_counts=None):
    """Print analytics with status breakdown"""
    print(f"\n\033[35m📊 WORKORDER ANALYTICS\033[0m")
    print(f"\033[36m{'='*50}\033[0m")
    
    # Status breakdown
    if status_counts:
        print("\033[33m📋 Status Breakdown:\033[0m")
        for status, count in status_counts.items():
            print(f"  • {status}: {count}")
    
    # Main stats
    print(f"\033[33m📥 Raw API Response:\033[0m {raw_count} workorders")
    print(f"\033[32m✅ Valid Orders:\033[0m {valid_count} (passed date/time validation)")
    print(f"\033[34m🔄 Already Synced:\033[0m {synced_count}")
    print(f"\033[32m🆕 New to Process:\033[0m {new_count}")
    
    # Sync rate calculation
    if valid_count > 0:
        sync_rate = (synced_count / valid_count) * 100
        if sync_rate > 80:
            color = "\033[32m"  # Green
        elif sync_rate > 50:
            color = "\033[33m"  # Yellow
        else:
            color = "\033[31m"  # Red
        print(f"\033[35m📈 Sync Rate:\033[0m {color}{sync_rate:.1f}%\033[0m")
    
    # Skip reasons breakdown
    if skipped_reasons:
        print(f"\n\033[31m⚠️ SKIPPED ORDERS BREAKDOWN:\033[0m")
        for reason, count in skipped_reasons.items():
            print(f"  • {reason}: {count}")
    
    print(f"\033[36m{'='*50}\033[0m\n")

def get_workorders_by_status(date: str, status: str):
    """Helper function to fetch workorders for a specific status"""
    url = f"{OUTSMART_BASE_URL}/GetWorkorders/?token=&software_token=&status={status}&update_status=false&key=WorkDate&value={date}&operator=eq"
    print(f"[🔍] Fetching {status} workorders from: {url}")
    
    try:
        response = httpx.get(url, headers=HEADERS, timeout=30)
        response.raise_for_status()
        return response.json().get("response", [])
    except Exception as e:
        print(f"[❌] Error fetching {status} workorders: {e}")
        return []

def get_latest_workorders_by_execution(check_synced=True):
    """Fetch today's workorders with status=Opgehaald OR Klaargezet based on Execution Date and Time"""
    try:
        today = datetime.now().strftime("%Y-%m-%d")
        
        # Fetch both statuses
        opgehaald_orders = get_workorders_by_status(today, "Opgehaald")
        klaargezet_orders = get_workorders_by_status(today, "Klaargezet")
        
        # Combine orders
        all_orders = opgehaald_orders + klaargezet_orders
        
        # Remove duplicates based on order ID
        seen_ids = set()
        unique_orders = []
        for order in all_orders:
            order_id = str(order.get("id"))
            if order_id not in seen_ids:
                seen_ids.add(order_id)
                unique_orders.append(order)

        data = unique_orders
        raw_count = len(data)
        print(f"[📊] Combined workorders: {raw_count} (Opgehaald: {len(opgehaald_orders)}, Klaargezet: {len(klaargezet_orders)})")
        
        if not isinstance(data, list) or len(data) == 0:
            print("[⚠️] No workorders with status=Opgehaald or Klaargezet found for today.")
            print_order_analytics(0, 0, 0, 0, {})
            return []

        raw_count = len(data)
        print(f"[📊] Raw API response: {raw_count} workorders received")
        
        # Filter by WorkDate and WorkTime (ED&T)
        today_str = datetime.now().strftime("%d-%m-%Y")
        valid_orders = []
        skipped_reasons = {}
        
        for row in data:
            wd, wt = row.get("WorkDate"), row.get("WorkTime")
            order_id = row.get("id")
            
            if not wd or not wt:
                reason = "Missing WorkDate or WorkTime"
                skipped_reasons[reason] = skipped_reasons.get(reason, 0) + 1
                print(f"[⚠️] Skipping order {order_id} - {reason}")
                continue
            
            if wd.strip() != today_str:
                reason = f"WorkDate mismatch ({wd} != {today_str})"
                skipped_reasons[reason] = skipped_reasons.get(reason, 0) + 1
                print(f"[⚠️] Skipping order {order_id} - {reason}")
                continue
            
            try:
                execution_start = datetime.strptime(f"{wd} {wt}", "%d-%m-%Y %H:%M")
                valid_orders.append(row)
                print(f"[✅] Valid order {order_id} - WorkDate: {wd}, WorkTime: {wt}")
            except ValueError as e:
                reason = "Invalid date/time format"
                skipped_reasons[reason] = skipped_reasons.get(reason, 0) + 1
                print(f"[❌] Skipping order {order_id} - {reason}: {e}")
                continue

        valid_count = len(valid_orders)
        
        if not valid_orders:
            print("[⚠️] No valid workorders with proper ED&T for today found.")
            print_order_analytics(raw_count, 0, 0, 0, skipped_reasons)
            return []

        # Apply sync filtering if requested
        if check_synced:
            synced_ids = get_synced_workorder_ids()
            new_orders = []
            synced_count = 0
            
            print(f"[🔍] Checking against {len(synced_ids)} previously synced workorders...")
            
            for order in valid_orders:
                order_id = str(order.get("id", ""))
                if order_id in synced_ids:
                    synced_count += 1
                    print(f"[🔄] Already synced: {order_id} - {order.get('CustomerName', 'Unknown')}")
                else:
                    new_orders.append(order)
                    print(f"[🆕] New order: {order_id} - {order.get('CustomerName', 'Unknown')} ({order.get('CustomerCity', 'Unknown City')})")
            
            final_orders = new_orders
            new_count = len(new_orders)
            
            print_order_analytics(raw_count, valid_count, synced_count, new_count, skipped_reasons)
            
            if new_count == 0:
                print(f"[✅] All {valid_count} valid workorders have already been synced!")
                return []
            
            print(f"[✅] Found {new_count} NEW workorders to process")
            return final_orders
        else:
            # No sync checking - return all valid orders
            print_order_analytics(raw_count, valid_count, 0, valid_count, skipped_reasons)
            print(f"[✅] Found {valid_count} workorders with status=Opgehaald for today's ED&T")
            return valid_orders
        
    except Exception as e:
        print(f"[❌] Error fetching today's workorders: {e}")
        print_order_analytics(0, 0, 0, 0, {"API Error": 1})
        return []

def get_workorders_for_date(workdate, check_synced=True):
    """
    Fetch all workorders with status=Opgehaald for a specific WorkDate (YYYY-MM-DD)
    
    Args:
        workdate (str): Date in DD-MM-YYYY format
        check_synced (bool): If True, filter out already synced workorders
    """
    try:
        # Convert DD-MM-YYYY to YYYY-MM-DD for API
        try:
            dt = datetime.strptime(workdate, "%d-%m-%Y")
            api_date = dt.strftime("%Y-%m-%d")
        except ValueError:
            print(f"[❌] Invalid date format: {workdate}")
            return []
        
        # Fetch both statuses
        opgehaald_orders = get_workorders_by_status(api_date, "Opgehaald")
        klaargezet_orders = get_workorders_by_status(api_date, "Klaargezet")
        
        # Combine and deduplicate
        all_orders = opgehaald_orders + klaargezet_orders
        seen_ids = set()
        data = []
        for order in all_orders:
            order_id = str(order.get("id"))
            if order_id not in seen_ids:
                seen_ids.add(order_id)
                data.append(order)
        
        raw_count = len(data)
        
        if check_synced and data:
            synced_ids = get_synced_workorder_ids()
            new_data = [order for order in data if str(order.get("id", "")) not in synced_ids]
            synced_count = raw_count - len(new_data)
            
            print_order_analytics(raw_count, raw_count, synced_count, len(new_data), {})
            print(f"[✅] Found {len(new_data)} NEW workorders (out of {raw_count} total) for {workdate}")
            return new_data
        else:
            print(f"[✅] Found {raw_count} workorders with status=Opgehaald for {workdate}")
            return data
        
    except Exception as e:
        print(f"[❌] Error fetching workorders for date {workdate}: {e}")
        return []

def get_workorders_by_date_range(start_date: str, end_date: str = None, check_synced=True):
    """
    Fetch workorders for a date range. Dates should be in YYYY-MM-DD format.
    
    Args:
        start_date (str): Start date in YYYY-MM-DD format
        end_date (str): End date in YYYY-MM-DD format (optional)
        check_synced (bool): If True, filter out already synced workorders
    """
    try:
        start_dt = datetime.strptime(start_date, "%Y-%m-%d")
        end_dt = datetime.strptime(end_date, "%Y-%m-%d") if end_date else start_dt
        
        all_orders = []
        current_dt = start_dt
        total_raw = 0
        total_new = 0
        
        print(f"[🔍] Processing date range: {start_date} to {end_dt.strftime('%Y-%m-%d')}")
        
        while current_dt <= end_dt:
            workdate = current_dt.strftime("%d-%m-%Y")
            print(f"\n[📅] Processing date: {workdate}")
            orders = get_workorders_for_date(workdate, check_synced)
            all_orders.extend(orders)
            total_new += len(orders)
            current_dt += timedelta(days=1)
        
        print(f"\n[✅] DATE RANGE SUMMARY:")
        print(f"  📊 Total NEW workorders: {total_new}")
        print(f"  📅 Date range: {start_date} to {end_dt.strftime('%Y-%m-%d')}")
        
        return all_orders
        
    except ValueError as e:
        print(f"[❌] Invalid date format: {e}")
        return []
    except Exception as e:
        print(f"[❌] Error fetching workorders by date range: {e}")
        return []

def get_all_unsynced_workorders():
    """Fetch all workorders with status=Opgehaald from Outsmart that have not been synced yet (no date filter)."""
    try:
        url = f"{OUTSMART_BASE_URL}/GetWorkorders/?token=&software_token=&update_status=false"
        print(f"[🔍] Fetching ALL workorders from API...")
        
        response = httpx.get(url, headers=HEADERS, timeout=30)
        response.raise_for_status()
        all_orders = response.json().get("response", [])
        
        raw_count = len(all_orders)
        print(f"[📊] Raw API response: {raw_count} total workorders")
        
        # Filter by status=Opgehaald first
        opgehaald_orders = [o for o in all_orders if o.get("status", "").lower() == "opgehaald"]
        opgehaald_count = len(opgehaald_orders)
        
        synced_ids = get_synced_workorder_ids()
        new_orders = [o for o in opgehaald_orders if str(o.get("id", "")) not in synced_ids]
        synced_count = opgehaald_count - len(new_orders)
        
        # Enhanced analytics for all unsynced
        print(f"\n\033[35m📊 ALL UNSYNCED WORKORDERS ANALYTICS\033[0m")
        print(f"\033[36m{'='*55}\033[0m")
        print(f"\033[33m📥 Total API Response:\033[0m {raw_count} workorders")
        print(f"\033[32m✅ Status=Opgehaald:\033[0m {opgehaald_count}")
        print(f"\033[34m🔄 Already Synced:\033[0m {synced_count}")
        print(f"\033[32m🆕 New to Process:\033[0m {len(new_orders)}")
        
        if opgehaald_count > 0:
            sync_rate = (synced_count / opgehaald_count) * 100
            color = "\033[32m" if sync_rate > 80 else "\033[33m" if sync_rate > 50 else "\033[31m"
            print(f"\033[35m📈 Overall Sync Rate:\033[0m {color}{sync_rate:.1f}%\033[0m")
        
        print(f"\033[36m{'='*55}\033[0m\n")
        
        print(f"[✅] Found {len(new_orders)} unsynced workorders with status=Opgehaald")
        return new_orders
        
    except Exception as e:
        print(f"[❌] Error fetching unsynced workorders: {e}")
        return []

def update_outsmart_status(order_id: str, status: str) -> bool:
    """Update workorder status in Outsmart"""
    try:
        url = f"{OUTSMART_BASE_URL}/UpdateWorkorder/"
        payload = {"workorder_no": order_id, "status": status}
        resp = httpx.post(url, headers=HEADERS, json=payload, timeout=30)
        return resp.status_code == 200
    except Exception as e:
        print(f"[❌] Error updating workorder status: {e}")
        return False

def mark_workorder_synced(order_id):
    """Mark a workorder as synced"""
    try:
        os.makedirs("app/logs", exist_ok=True)
        with open("app/logs/synced_workorders.txt", "a", encoding="utf-8") as f:
            f.write(f"{order_id}\n")
    except Exception as e:
        print(f"[❌] Error marking workorder as synced: {e}")

def get_failed_workorders():
    """Fetch workorders that have failed to sync (for retry functionality)."""
    try:
        url = f"{OUTSMART_BASE_URL}/GetWorkorders/?token=&software_token=&update_status=false"
        response = httpx.get(url, headers=HEADERS, timeout=30)
        response.raise_for_status()
        all_orders = response.json().get("response", [])
        
        failed_orders = []
        for order in all_orders:
            status = order.get("status", "").lower()
            if "error" in status or "failed" in status or "circuit_error" in status:
                failed_orders.append(order)
        
        print(f"[✅] Found {len(failed_orders)} failed workorders")
        return failed_orders
        
    except Exception as e:
        print(f"[❌] Error fetching failed workorders: {e}")
        return []
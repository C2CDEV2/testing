import httpx, os, json, time
import unicodedata
from datetime import datetime, timedelta
from .config import OUTSMART_BASE_URL, OUTSMART_BEARER, CIRCUIT_BASE, CIRCUIT_API_KEY

OUTSMART_HEADERS = {"Authorization": f"Bearer {OUTSMART_BEARER}", "Accept": "*/*"}
CIRCUIT_HEADERS = {"Authorization": f"Bearer {CIRCUIT_API_KEY}", "Content-Type": "application/json"}

CACHE_DIR = "app/logs"
DRIVERS_CACHE_FILE = f"{CACHE_DIR}/drivers.json"
EMPLOYEES_CACHE_FILE = f"{CACHE_DIR}/employees.json"
TIMESTAMP_FILE = f"{CACHE_DIR}/cache_timestamp.txt"
CACHE_DURATION_DAYS = 7

def get_driver_email_blocklist():
    try:
        env_val = os.getenv("BLOCKED_DRIVER_EMAILS", "")
        env_blocked = {e.strip().lower() for e in env_val.split(",") if e.strip()}
        default_blocked = {"r.brito@airbel.pt", "dev@company.com", "test@company.com", "developer@test.com"}
        return default_blocked.union(env_blocked)
    except Exception:
        return {"r.brito@airbel.pt", "dev@company.com", "test@company.com", "developer@test.com"}

def _normalize_string(value: str) -> str:
    try:
        if value is None:
            return ""
        # Remove diacritics, lowercase, strip extra spaces
        nfkd_form = unicodedata.normalize('NFKD', str(value))
        without_accents = "".join([c for c in nfkd_form if not unicodedata.combining(c)])
        return " ".join(without_accents.lower().split())
    except Exception:
        return (value or "").strip().lower()

def _build_employee_display_name(employee: dict) -> str:
    firstname = employee.get("firstname", "")
    lastname = employee.get("lastname", "")
    return f"{firstname} {lastname}".strip()

def ensure_cache_directory():
    try:
        os.makedirs(CACHE_DIR, exist_ok=True)
        return True
    except Exception as e:
        print(f"[❌] Error creating cache directory: {e}")
        return False

def get_cache_timestamp():
    try:
        if os.path.exists(TIMESTAMP_FILE):
            with open(TIMESTAMP_FILE, 'r') as f:
                timestamp_str = f.read().strip()
                return datetime.fromisoformat(timestamp_str)
    except Exception as e:
        print(f"[⚠️] Error reading cache timestamp: {e}")
    return None

def update_cache_timestamp():
    try:
        ensure_cache_directory()
        with open(TIMESTAMP_FILE, 'w') as f:
            f.write(datetime.now().isoformat())
        return True
    except Exception as e:
        print(f"[❌] Error updating cache timestamp: {e}")
        return False

def is_cache_expired():
    try:
        last_update = get_cache_timestamp()
        if not last_update:
            return True
        expiry_date = last_update + timedelta(days=CACHE_DURATION_DAYS)
        return datetime.now() > expiry_date
    except Exception as e:
        print(f"[⚠️] Error checking cache expiry: {e}")
        return True

def is_cache_empty():
    try:
        drivers_exist = os.path.exists(DRIVERS_CACHE_FILE) and os.path.getsize(DRIVERS_CACHE_FILE) > 0
        employees_exist = os.path.exists(EMPLOYEES_CACHE_FILE) and os.path.getsize(EMPLOYEES_CACHE_FILE) > 0
        return not (drivers_exist and employees_exist)
    except Exception:
        return True

def fetch_circuit_drivers():
    try:
        if not CIRCUIT_API_KEY:
            print("[❌] Circuit API key not configured")
            return []
        
        url = f"{CIRCUIT_BASE}/drivers?filter[active]=true&maxPageSize=50"
        response = httpx.get(url, headers=CIRCUIT_HEADERS, timeout=30)
        
        if response.status_code == 401:
            print("[❌] Circuit API authentication failed - check CIRCUIT_API_KEY")
            return []
        
        response.raise_for_status()
        data = response.json()
        
        drivers = []
        blocked = get_driver_email_blocklist()
        for driver in data.get("drivers", []):
            if driver.get("active", False):
                name = (driver.get("name") or "").strip()
                email = (driver.get("email") or "").strip()
                if not name:
                    continue
                if email and email.strip().lower() in blocked:
                    continue
                # Normalize depots to a list of depot IDs (strings)
                raw_depots = driver.get("depots", [])
                depot_ids = []
                try:
                    for d in raw_depots:
                        if isinstance(d, dict):
                            dep_id = d.get("id") or d.get("depotId")
                            if dep_id:
                                depot_ids.append(dep_id)
                        else:
                            depot_ids.append(d)
                except Exception:
                    depot_ids = [d for d in raw_depots if isinstance(d, str)]
                driver_info = {
                    "id": driver.get("id"),
                    "name": name,
                    "email": email,
                    "active": driver.get("active", False),
                    "depots": depot_ids
                }
                drivers.append(driver_info)
        
        print(f"[✅] Fetched {len(drivers)} active drivers from Circuit")
        return drivers
    except Exception as e:
        print(f"[❌] Error fetching Circuit drivers: {e}")
        return []

def fetch_outsmart_employees():
    try:
        if not OUTSMART_BEARER:
            print("[❌] Outsmart Bearer token not configured")
            return []
        
        url = f"{OUTSMART_BASE_URL}/employees/?token=&software_token="
        response = httpx.get(url, headers=OUTSMART_HEADERS, timeout=30)
        
        if response.status_code == 401:
            print("[❌] Outsmart API authentication failed - check OUTSMART_BEARER")
            return []
        
        response.raise_for_status()
        data = response.json()
        
        employees = []
        for employee in data.get("response", []):
            employee_info = {
                "firstname": employee.get("firstname", ""),
                "lastname": employee.get("lastname", ""),
                "number": employee.get("number", ""),
                "email": employee.get("email", "")
            }
            if employee_info["number"]:
                employees.append(employee_info)
        
        print(f"[✅] Fetched {len(employees)} employees from Outsmart")
        return employees
    except Exception as e:
        print(f"[❌] Error fetching Outsmart employees: {e}")
        return []

def save_cache_to_files(drivers, employees):
    try:
        ensure_cache_directory()
        
        with open(DRIVERS_CACHE_FILE, 'w', encoding='utf-8') as f:
            json.dump(drivers, f, indent=2, ensure_ascii=False)
        
        with open(EMPLOYEES_CACHE_FILE, 'w', encoding='utf-8') as f:
            json.dump(employees, f, indent=2, ensure_ascii=False)
        
        update_cache_timestamp()
        print(f"[✅] Cache updated successfully")
        return True
    except Exception as e:
        print(f"[❌] Error saving cache to files: {e}")
        return False

def load_cache_from_files():
    try:
        drivers = []
        employees = []
        
        if os.path.exists(DRIVERS_CACHE_FILE):
            with open(DRIVERS_CACHE_FILE, 'r', encoding='utf-8') as f:
                drivers = json.load(f)
        
        if os.path.exists(EMPLOYEES_CACHE_FILE):
            with open(EMPLOYEES_CACHE_FILE, 'r', encoding='utf-8') as f:
                employees = json.load(f)
        
        return drivers, employees
    except Exception as e:
        print(f"[❌] Error loading cache from files: {e}")
        return [], []

def update_cache_if_needed():
    try:
        if is_cache_empty():
            print("[🔄] Cache is empty, fetching fresh data...")
            drivers = fetch_circuit_drivers()
            employees = fetch_outsmart_employees()
            if drivers or employees:
                save_cache_to_files(drivers, employees)
                return drivers, employees
            else:
                print("[⚠️] Failed to fetch fresh data")
                return [], []
        
        if is_cache_expired():
            print("[🔄] Cache expired, fetching fresh data...")
            drivers = fetch_circuit_drivers()
            employees = fetch_outsmart_employees()
            if drivers or employees:
                save_cache_to_files(drivers, employees)
                return drivers, employees
            else:
                print("[⚠️] Failed to fetch fresh data, using existing cache")
                return load_cache_from_files()
        
        return load_cache_from_files()
    except Exception as e:
        print(f"[❌] Error updating cache: {e}")
        return load_cache_from_files()

def get_driver_by_employee_email(employee_email):
    try:
        if not employee_email:
            return None, None, "no_email"
        
        drivers, employees = update_cache_if_needed()
        
        if not drivers:
            return None, None, "no_drivers"
        
        employee_email = employee_email.strip().lower()
        if employee_email in get_driver_email_blocklist():
            return None, None, f"blocked_email:{employee_email}"
        
        matching_driver = next(
            (d for d in drivers if (d.get("email") or "").strip().lower() == employee_email),
            None
        )
        if not matching_driver:
            return None, None, f"no_driver_match:{employee_email}"
        
        depots = matching_driver.get("depots", [])
        driver_id = matching_driver.get("id")
        depot_id = depots[0] if depots else None

        # Do not fail if no depot; allow caller to choose a fallback depot while keeping driver match
        if depot_id:
            try:
                res = httpx.get(f"{CIRCUIT_BASE}/depots", headers=CIRCUIT_HEADERS, timeout=30)
                res.raise_for_status()
                valid_ids = {d.get("id") for d in res.json().get("depots", [])}
                if depot_id not in valid_ids:
                    # Clear invalid depot; caller will fallback
                    depot_id = None
            except Exception:
                # On validation issues, keep depot_id as is (or None) and let caller decide
                pass

        if depot_id:
            print(f"[✅] Matched {employee_email} → {matching_driver.get('name')} → Driver:{driver_id} Depot:{depot_id}")
            return driver_id, depot_id, f"email_match:{employee_email}"
        else:
            print(f"[ℹ️] Matched {employee_email} → {matching_driver.get('name')} with no/invalid depot; will fallback later")
            return driver_id, None, f"email_match_no_depot:{employee_email}"
        
    except Exception as e:
        print(f"[❌] Error matching email to driver: {e}")
        return None, None, f"error:{e}"

def get_driver_by_employee_number(employee_number):
    try:
        if not employee_number:
            return None, None, "no_employee_number"
        
        drivers, employees = update_cache_if_needed()
        
        if not drivers or not employees:
            return None, None, "no_cache_data"
        
        employee = next((emp for emp in employees if str(emp.get("number", "")) == str(employee_number)), None)
        
        if not employee:
            return None, None, f"employee_not_found:{employee_number}"
        
        employee_email = employee.get("email", "").strip()
        if not employee_email:
            return None, None, f"no_email_for_employee:{employee_number}"
        
        driver_id, depot_id, source = get_driver_by_employee_email(employee_email)
        if driver_id:
            return driver_id, depot_id, f"employee_number:{employee_number}→{source}"

        # Fallback 2: try name-based matching if email failed/mismatched
        try:
            drivers, _ = update_cache_if_needed()
            employee_name_norm = _normalize_string(_build_employee_display_name(employee))
            best_match = None
            for d in drivers:
                driver_name_norm = _normalize_string(d.get("name", ""))
                if driver_name_norm == employee_name_norm or (
                    employee_name_norm and driver_name_norm.startswith(employee_name_norm)
                ):
                    best_match = d
                    break
            if best_match:
                depots = best_match.get("depots", [])
                depot_id_nm = depots[0] if depots else None
                print(f"[✅] Name match {employee_name_norm} → {best_match.get('name')} (Driver:{best_match.get('id')})")
                return best_match.get("id"), depot_id_nm, f"name_match:{employee_name_norm}"
        except Exception as e:
            print(f"[⚠️] Name-based driver matching error: {e}")

        return None, None, f"failed_employee_lookup:{employee_number}→{source}"
        
    except Exception as e:
        print(f"[❌] Error matching employee to driver: {e}")
        return None, None, f"error:{e}"
import time
from collections import defaultdict
from datetime import datetime
import httpx
from .outsmart_client import (
    get_latest_workorders_by_execution,
    get_all_unsynced_workorders,
    get_workorders_by_date_range,
    get_failed_workorders,
    update_outsmart_status,
    mark_workorder_synced
)
from .circuit_client import (
    get_or_create_driver_plan,
    send_stop,
    process_plan_optimization_and_distribution,
    log_circuit,
    get_depot_name_by_id,
    get_driver_name_by_id
)
from .driver_employee_cache import get_driver_by_employee_number
from .config import CIRCUIT_BASE, CIRCUIT_API_KEY

DEPOT_CACHE = {}
STATUS_SENT_TO_CIRCUIT = "SENT_TO_CIRCUIT"
STATUS_OPTIMIZED_AND_DISTRIBUTED = "OPTIMIZED_AND_DISTRIBUTED"
STATUS_CIRCUIT_ERROR = "CIRCUIT_ERROR"
LISBOA_KEYWORDS = ["lisboa", "porto", "lisbon"]
MAIA_KEYWORDS = ["maia"]

def get_fallback_depot_id(city):
    """Get fallback depot based on city when driver matching fails"""
    try:
        if "depots" in DEPOT_CACHE:
            depots = DEPOT_CACHE["depots"]
        else:
            headers = {"Authorization": f"Bearer {CIRCUIT_API_KEY}", "Content-Type": "application/json"}
            res = httpx.get(f"{CIRCUIT_BASE}/depots", headers=headers, timeout=30)
            if res.status_code == 200:
                depots = res.json().get("depots", [])
                DEPOT_CACHE["depots"] = depots
            else:
                return None, "depot_fetch_error"
        
        city_lower = city.lower()
        
        if any(kw in city_lower for kw in LISBOA_KEYWORDS):
            for depot in depots:
                if "lisboa" in depot.get("name", "").lower():
                    return depot["id"], f"city_lisboa:{city}"
        else:
            for depot in depots:
                if any(kw in depot.get("name", "").lower() for kw in MAIA_KEYWORDS):
                    return depot["id"], f"city_maia:{city}"
        
        if depots:
            return depots[0]["id"], f"fallback_first:{depots[0].get('name','unknown')}"
        
        return None, "no_depots_available"
    except Exception as e:
        log_circuit("Error in fallback depot assignment", {"error": str(e)})
        return None, f"error:{e}"

def process_orders_batch(orders):
    """Process orders with driver-specific plan grouping"""
    driver_groups = defaultdict(list)  # (work_date, driver_id) -> orders
    fallback_groups = defaultdict(list)  # (work_date, depot_id) -> orders without driver match
    assignment_sources = defaultdict(int)
    
    for order in orders:
        work_date_str = order.get("WorkDate", "")
        if not work_date_str:
            log_circuit("Missing WorkDate in order, skipping", {"order_id": order.get("id")})
            print(f"\033[31m❌ Skipping order due to missing WorkDate:\033[0m {order.get('id')}")
            continue
        
        # Standardize work_date format
        work_date = None
        for fmt in ["%Y-%m-%d", "%d-%m-%Y"]:
            try:
                work_date = datetime.strptime(work_date_str, fmt).strftime("%d-%m-%Y")
                break
            except ValueError:
                pass
        if not work_date:
            log_circuit("Invalid WorkDate format, skipping", {"order_id": order.get("id"), "work_date": work_date_str})
            print(f"\033[31m❌ Skipping order due to invalid WorkDate format:\033[0m {order.get('id')} {work_date_str}")
            continue
        
        employee_number = order.get("EmployeeNr", "")
        city = order.get("CustomerCity", "")
        customer_name = order.get("CustomerName", "")
        
        # Try driver matching first
        driver_id, depot_id, assignment_source = get_driver_by_employee_number(employee_number)
        assignment_sources[assignment_source] += 1
        
        if driver_id:
            # Success: assign to driver-specific plan. If depot_id missing/invalid, we will try fallback depot.
            order["force_driver_id"] = driver_id
            if depot_id:
                order["force_depot_id"] = depot_id
            else:
                # Try fallback depot by city while keeping driver association
                fallback_depot_id, fallback_source = get_fallback_depot_id(city)
                if fallback_depot_id:
                    order["force_depot_id"] = fallback_depot_id
                    assignment_sources[f"driver_no_depot→{fallback_source}"] += 1
                else:
                    assignment_sources["driver_no_depot_no_fallback"] += 1
            driver_groups[(work_date, driver_id)].append(order)
            
            log_circuit("Driver assignment successful", {
                "order_id": order.get("id"),
                "driver_id": driver_id,
                "depot_id": depot_id,
                "source": assignment_source
            })
        else:
            # Fallback: try depot assignment for unmatched orders
            fallback_depot_id, fallback_source = get_fallback_depot_id(city)
            assignment_sources[fallback_source] += 1
            
            if fallback_depot_id:
                order["force_depot_id"] = fallback_depot_id
                fallback_groups[(work_date, fallback_depot_id)].append(order)
                
                log_circuit("Fallback depot assignment", {
                    "order_id": order.get("id"),
                    "depot_id": fallback_depot_id,
                    "source": fallback_source,
                    "original_error": assignment_source
                })
            else:
                log_circuit("No assignment possible, skipping", {
                    "order_id": order.get("id"),
                    "employee_number": employee_number,
                    "city": city,
                    "driver_error": assignment_source,
                    "fallback_error": fallback_source
                })
                print(f"\033[31m❌ No assignment possible, skipping:\033[0m {order.get('id')}")
                continue
    
    results = []
    plan_processed = set()
    processed_count = 0
    start_time = time.time()
    
    # Process driver-specific groups first
    print(f"\033[34m🚀 Processing {len(driver_groups)} driver-specific plan groups\033[0m")
    for (work_date, driver_id), group_orders in driver_groups.items():
        try:
            driver_name = get_driver_name_by_id(driver_id) or "Unknown Driver"
            depot_id = group_orders[0].get("force_depot_id")  # All orders in group should carry a depot by now
            depot_name = get_depot_name_by_id(depot_id) or "Unknown Depot"
            
            plan_id = get_or_create_driver_plan(work_date, driver_id, depot_id)
            if not plan_id:
                log_circuit("Failed to create driver plan; skipping group", {
                    "work_date": work_date,
                    "driver_id": driver_id,
                    "depot_id": depot_id
                })
                print(f"\033[31m❌ Failed to get driver plan, skipping:\033[0m {work_date} {driver_name}")
                for order in group_orders:
                    results.append({
                        "success": False,
                        "order_id": order.get("id"),
                        "error": "No driver plan available"
                    })
                    update_outsmart_status(order.get("id"), STATUS_CIRCUIT_ERROR)
                continue

            stop_ids = []
            group_size = len(group_orders)
            for idx, order in enumerate(group_orders, 1):
                print(f"\033[33m📤 Sending stop {idx}/{group_size} for driver plan {plan_id} ({driver_name} @ {depot_name})\033[0m")
                resp = send_stop({**order, "force_plan_id": plan_id})
                if resp.get("success"):
                    stop_id = resp["response"].get("id")
                    stop_ids.append(stop_id)
                    customer_name = order.get("CustomerName", "Unknown Customer")
                    print(f"\033[32m✅ Stop sent for workorder {order.get('id')} ({customer_name})\033[0m")
                    print(f"  \033[36m🚛 Driver: {driver_name} @ {depot_name}\033[0m")
                    print(f"  \033[36m📍 stop_id={stop_id}\033[0m")
                    print(f"  \033[36m📋 plan_id={plan_id}\033[0m")
                    mark_workorder_synced(order.get("id"))
                    update_outsmart_status(order.get("id"), STATUS_SENT_TO_CIRCUIT)
                    results.append({
                        "success": True,
                        "order_id": order.get("id"),
                        "plan_id": plan_id,
                        "stop_id": stop_id,
                        "driver_id": driver_id
                    })
                else:
                    print(f"\033[31m❌ Failed to send stop for workorder {order.get('id')}: {resp.get('error')}\033[0m")
                    results.append({
                        "success": False,
                        "order_id": order.get("id"),
                        "error": resp.get("error")
                    })
                    time.sleep(0.22)

            # Optimize and distribute driver plan
            if plan_id not in plan_processed and stop_ids:
                if processed_count > 0:
                    delay = min(10, processed_count * 2)
                    print(f"\033[33m⏳ Waiting {delay} seconds before processing next plan...\033[0m")
                    time.sleep(delay)
                    
                print(f"\033[34m🚀 Optimizing and distributing driver plan {plan_id} ({driver_name}) with {len(stop_ids)} stops\033[0m")
                plan_processed.add(plan_id)
                try:
                    plan_result = process_plan_optimization_and_distribution(plan_id)
                    if plan_result.get("success"):
                        print(f"\033[32m✅ Driver plan {plan_id} ({driver_name}) optimized and distributed\033[0m")
                        for result in results:
                            if result.get("plan_id") == plan_id and result.get("success"):
                                update_outsmart_status(result.get("order_id"), STATUS_OPTIMIZED_AND_DISTRIBUTED)
                    else:
                        error_msg = plan_result.get("error", "Unknown error")
                        print(f"\033[31m❌ Failed to optimize/distribute driver plan {plan_id} ({driver_name}): {error_msg}\033[0m")
                        if "already distributed" in str(error_msg).lower():
                            print(f"\033[36mℹ️ Driver plan {plan_id} ({driver_name}) already distributed, marking successful\033[0m")
                            for result in results:
                                if result.get("plan_id") == plan_id and result.get("success"):
                                    update_outsmart_status(result.get("order_id"), STATUS_OPTIMIZED_AND_DISTRIBUTED)
                        else:
                            for result in results:
                                if result.get("plan_id") == plan_id and result.get("success"):
                                    update_outsmart_status(result.get("order_id"), STATUS_CIRCUIT_ERROR)
                except Exception as e:
                    print(f"\033[31m❌ Error processing driver plan {plan_id} ({driver_name}): {str(e)}\033[0m")
                    log_circuit("Driver plan processing error", {"plan_id": plan_id, "driver_id": driver_id, "error": str(e)})
                    for result in results:
                        if result.get("plan_id") == plan_id and result.get("success"):
                            update_outsmart_status(result.get("order_id"), STATUS_CIRCUIT_ERROR)
            
            processed_count += 1

        except Exception as e:
            print(f"\033[31m❌ Error processing driver group ({work_date}, {driver_name}): {str(e)}\033[0m")
            log_circuit("Driver group processing error", {"work_date": work_date, "driver_id": driver_id, "error": str(e)})
            for order in group_orders:
                results.append({
                    "success": False,
                    "order_id": order.get("id"),
                    "error": str(e)
                })

    # Process fallback depot groups for unmatched orders
    if fallback_groups:
        print(f"\033[33m⚠️ Processing {len(fallback_groups)} fallback depot groups for unmatched orders\033[0m")
        # Implementation would be similar but create depot-based plans instead of driver plans
        # For brevity, this is left as a TODO - these orders would go to depot-based plans
        # where Circuit can assign any available driver
    
    total_time = time.time() - start_time
    successful = sum(1 for r in results if r.get("success"))
    failed = len(results) - successful
    total_orders = len(orders)
    skipped = total_orders - len(results)
    
    print("\n\033[35m📊 Processing Summary:\033[0m")
    print(f"  Total Orders: {total_orders}")
    print(f"  Skipped: {skipped} (missing/invalid WorkDate or no assignment)")
    print(f"  Processed: {successful + failed}")
    print(f"  Successful: \033[32m{successful}\033[0m")
    print(f"  Failed: \033[31m{failed}\033[0m")
    print(f"  Time Taken: {total_time:.2f} seconds")
    
    if assignment_sources:
        print("\033[35m🎯 Assignment Source Breakdown:\033[0m")
        for source, count in sorted(assignment_sources.items(), key=lambda x: x[1], reverse=True):
            print(f"  {source}: {count}")
    
    return results

def sync_routes():
    print("\033[34m🚀 Starting Outsmart → Circuit integration (Production Mode)\033[0m")
    print("\033[36m📅 Fetching today's workorders with status=Opgehaald...\033[0m")
    
    orders = get_latest_workorders_by_execution()
    if not orders:
        print("\033[32m✅ No workorders to process\033[0m")
        return
    
    print(f"\033[33m📦 Processing {len(orders)} workorders...\033[0m")
    process_orders_batch(orders)

def sync_all_unsynced_routes():
    print("\033[34m🚀 Starting Outsmart → Circuit integration (Dev/Debug Mode)\033[0m")
    print("\033[36m📅 Fetching all unsynced workorders with status=Opgehaald...\033[0m")
    
    orders = get_all_unsynced_workorders()
    if not orders:
        print("\033[32m✅ No unsynced workorders to process\033[0m")
        return
    
    print(f"\033[33m📦 Processing {len(orders)} unsynced workorders...\033[0m")
    process_orders_batch(orders)

def sync_specific_date_range(start_date: str, end_date: str = None):
    print(f"\033[34m🚀 Starting Outsmart → Circuit integration for date range\033[0m")
    print(f"\033[36m📅 Fetching workorders from {start_date} to {end_date or start_date}...\033[0m")
    
    orders = get_workorders_by_date_range(start_date, end_date)
    if not orders:
        print("\033[32m✅ No workorders found for the specified date range\033[0m")
        return
    
    print(f"\033[33m📦 Processing {len(orders)} workorders...\033[0m")
    process_orders_batch(orders)

def retry_failed_orders():
    print("\033[34m🚀 Starting retry of failed workorders...\033[0m")
    
    orders = get_failed_workorders()
    if not orders:
        print("\033[32m✅ No failed workorders to retry\033[0m")
        return
    
    print(f"\033[33m📦 Retrying {len(orders)} failed workorders...\033[0m")
    process_orders_batch(orders)
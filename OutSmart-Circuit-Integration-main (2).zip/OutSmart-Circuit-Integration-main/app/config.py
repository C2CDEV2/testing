import os
from dotenv import load_dotenv
load_dotenv()

OUTSMART_BASE_URL = os.getenv("OUTSMART_BASE_URL") 
OUTSMART_BEARER = os.getenv("OUTSMART_BEARER")     

CIRCUIT_BASE = "https://api.getcircuit.com/public/v0.2b"
CIRCUIT_API_KEY = os.getenv("CIRCUIT_API_KEY")

REDIS_URL = os.getenv("REDIS_URL", "redis://localhost:6379/0")
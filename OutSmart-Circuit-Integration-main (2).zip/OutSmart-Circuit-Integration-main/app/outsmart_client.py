import httpx, os
from datetime import datetime
from .config import OUTSMART_BASE_URL, OUTSMART_BEARER

HEADERS = {
    "Authorization": f"Bearer {OUTSMART_BEARER}",
    "Accept": "*/*"
}

LOG_FILE = "app/logs/outsmart_fetch.txt"

def log_fetch(latest_dt, orders):
    os.makedirs(os.path.dirname(LOG_FILE), exist_ok=True)
    with open(LOG_FILE, "a", encoding="utf-8") as f:
        f.write(f"[{datetime.now().isoformat()}] Latest Execution: {latest_dt.strftime('%d-%m-%Y %H:%M')}, "
                f"Orders: {len(orders)}, OrderNr: {[o.get('OrderNr') for o in orders]}\n")

def get_latest_workorders_by_execution():
    url = f"{OUTSMART_BASE_URL}/GetWorkorders/?software_token=&update_status=false"
    response = httpx.get(url, headers=HEADERS, timeout=10)
    response.raise_for_status()
    data = response.json().get("response", [])

    if not isinstance(data, list) or len(data) == 0:
        print("[⚠️] API returned no workorders.")
        return []

    dated_orders = []
    for row in data:
        if str(row.get("Status", "")).strip().lower() not in ["pendente", "pending", "klaargezet"]:
            continue
        wd, wt = row.get("WorkDate"), row.get("WorkTime")
        if wd and wt:
            try:
                execution_start = datetime.strptime(f"{wd} {wt}", "%d-%m-%Y %H:%M")
                dated_orders.append((execution_start, row))
            except ValueError:
                continue

    if not dated_orders:
        print("[⚠️] No valid pending workorders with proper ED&T found.")
        return []

    latest_dt = max(dated_orders, key=lambda x: x[0])[0]
    latest_orders = [row for dt, row in dated_orders if dt == latest_dt]
    log_fetch(latest_dt, latest_orders)
    return latest_orders

def get_workorders_for_date(workdate):
    """Fetch all workorders with a specific WorkDate (DD-MM-YYYY)"""
    url = (
        f"{OUTSMART_BASE_URL}/GetWorkorders/"
        f"?software_token=&update_status=false"
        f"&key=WorkDate&value={workdate}&operator=eq"
    )
    response = httpx.get(url, headers=HEADERS, timeout=10)
    response.raise_for_status()
    return response.json().get("response", [])

def update_outsmart_status(order_id: str, status: str) -> bool:
    url = f"{OUTSMART_BASE_URL}/UpdateWorkorder/"
    payload = {"workorder_no": order_id, "status": status}
    resp = httpx.post(url, headers=HEADERS, json=payload)
    return resp.status_code == 200

def get_all_new_workorders():
    """Fetch all workorders for today that have not been synced yet."""
    from datetime import datetime
    today = datetime.now().strftime("%d-%m-%Y")
    all_orders = get_workorders_for_date(today)
    synced_ids = set()
    try:
        with open("app/logs/synced_workorders.txt", "r", encoding="utf-8") as f:
            synced_ids = set(line.strip() for line in f if line.strip())
    except FileNotFoundError:
        pass
    new_orders = [o for o in all_orders if str(o.get("id")) not in synced_ids]
    return new_orders

def mark_workorder_synced(order_id):
    with open("app/logs/synced_workorders.txt", "a", encoding="utf-8") as f:
        f.write(f"{order_id}\n")

def get_all_unsynced_workorders():
    """Fetch all workorders from Outsmart that have not been synced yet (no date filter)."""
    url = f"{OUTSMART_BASE_URL}/GetWorkorders/?software_token=&update_status=false"
    response = httpx.get(url, headers=HEADERS, timeout=10)
    response.raise_for_status()
    all_orders = response.json().get("response", [])
    synced_ids = set()
    try:
        with open("app/logs/synced_workorders.txt", "r", encoding="utf-8") as f:
            synced_ids = set(line.strip() for line in f if line.strip())
    except FileNotFoundError:
        pass
    new_orders = [o for o in all_orders if str(o.get("id")) not in synced_ids]
    return new_orders

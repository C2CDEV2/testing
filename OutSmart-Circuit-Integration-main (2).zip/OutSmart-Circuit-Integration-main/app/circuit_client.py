import httpx, os, json, time
from datetime import datetime
from .config import CIRCUIT_BASE, CIRCUIT_API_KEY
from collections import deque
from datetime import datetime
import unicodedata

HEADERS = {"Authorization": f"Bearer {CIRCUIT_API_KEY}", "Content-Type": "application/json"}
CIRCUIT_LOG = "app/logs/responses_2.txt"

# Global optimization rate limiter
OPTIMIZE_RATE_LIMIT = 3  # per minute
OPTIMIZE_WINDOW = 60  # seconds
optimize_timestamps = deque(maxlen=OPTIMIZE_RATE_LIMIT)

DEPOT_AREA_RULES = {
    "Lisboa": {
        "cities": ["Lisboa", "Avenidas Novas"],
        "postcodes_prefix": ["1050", "1000", "1100"]
    },
    "Maia": {
        "cities": ["Maia", "Nogueira"],
        "postcodes_prefix": ["4475", "4470"]
    }
}

def normalize_city(city):
    if not city:
        return ""
    city = city.strip().lower()
    city = unicodedata.normalize('NFKD', city).encode('ascii', 'ignore').decode('ascii')
    return city

def normalize_postcode(postcode):
    return postcode.replace(' ', '')[:4] if postcode else ""

def get_depot_id_by_name(depot_name):
    res = httpx.get(f"{CIRCUIT_BASE}/depots", headers=HEADERS)
    res.raise_for_status()
    for depot in res.json().get("depots", []):
        if depot["name"].strip().lower() == depot_name.strip().lower():
            return depot["id"]
    return None

def get_depot_name_by_id(depot_id):
    if not depot_id:
        return None
    res = httpx.get(f"{CIRCUIT_BASE}/depots", headers=HEADERS)
    res.raise_for_status()
    for depot in res.json().get("depots", []):
        if depot["id"] == depot_id:
            return depot["name"]
    return None

def get_depot_id_for_order(order):
    city = normalize_city(order.get("CustomerCity"))
    zip_code = normalize_postcode(order.get("CustomerZIP"))
    for depot_name, rules in DEPOT_AREA_RULES.items():
        if any(normalize_city(c) == city for c in rules["cities"]):
            return get_depot_id_by_name(depot_name)
        if any(zip_code.startswith(p) for p in rules["postcodes_prefix"]):
            return get_depot_id_by_name(depot_name)
    return None

def throttle_optimization():
    now = time.time()
    if len(optimize_timestamps) == OPTIMIZE_RATE_LIMIT:
        earliest = optimize_timestamps[0]
        wait_time = OPTIMIZE_WINDOW - (now - earliest)
        if wait_time > 0:
            print(f"[Rate Limit] Waiting {int(wait_time)+1} seconds before next optimization...")
            time.sleep(wait_time + 1)
    optimize_timestamps.append(time.time())

def log_circuit(message: str, data: dict):
    os.makedirs(os.path.dirname(CIRCUIT_LOG), exist_ok=True)
    if os.path.exists(CIRCUIT_LOG) and os.path.getsize(CIRCUIT_LOG) > 10_000_000:
        os.rename(CIRCUIT_LOG, CIRCUIT_LOG + ".old")
    with open(CIRCUIT_LOG, "a", encoding="utf-8") as f:
        f.write(f"\n== {datetime.now().isoformat()} {message} ==\n")
        f.write(json.dumps(data, ensure_ascii=False, indent=2) + "\n")

def get_all_driver_ids(depot_id: str = None) -> list:
    driver_ids = []
    url = f"{CIRCUIT_BASE}/drivers"
    params = {}
    while True:
        res = httpx.get(url, headers=HEADERS, params=params)
        res.raise_for_status()
        data = res.json()
        drivers = data.get("drivers", [])
        for d in drivers:
            if d.get("active", True):
                if depot_id:
                    if depot_id in d.get("depots", []):
                        driver_ids.append(d["id"])
                else:
                    driver_ids.append(d["id"])
        next_token = data.get("nextPageToken")
        if not next_token:
            break
        params["pageToken"] = next_token
    log_circuit("Fetched drivers", {"driver_ids": driver_ids, "depot_filter": depot_id})
    return driver_ids

def get_available_drivers(depot_id: str = None) -> list:
    url = f"{CIRCUIT_BASE}/drivers"
    params = {}
    available_drivers = []
    
    while True:
        res = httpx.get(url, headers=HEADERS, params=params)
        res.raise_for_status()
        data = res.json()
        drivers = data.get("drivers", [])
        
        for driver in drivers:
            if driver.get("active", True):
                driver_depots = driver.get("depots", [])
                if depot_id and depot_id not in driver_depots:
                    continue
                if not depot_id or depot_id in driver_depots:
                    available_drivers.append(driver)
        
        next_token = data.get("nextPageToken")
        if not next_token:
            break
        params["pageToken"] = next_token
    
    log_circuit("Fetched available drivers", {"count": len(available_drivers), "depot_filter": depot_id})
    return available_drivers

def get_or_create_plan(work_date: str, depot_id: str = None) -> str:
    from datetime import datetime
    try:
        dt = datetime.strptime(work_date, "%d-%m-%Y")
        date_str = dt.strftime("%Y-%m-%d")
        year, month, day = dt.year, dt.month, dt.day
    except Exception:
        log_circuit("Invalid WorkDate, using today", {"work_date": work_date})
        dt = datetime.now()
        date_str = dt.strftime("%Y-%m-%d")
        year, month, day = dt.year, dt.month, dt.day
    res = httpx.get(f"{CIRCUIT_BASE}/plans", headers=HEADERS)
    res.raise_for_status()
    existing_plans = res.json().get("items", [])
    log_circuit("Existing plans debug", {
        "date_str": date_str,
        "depot_id": depot_id,
        "existing_plan_count": len(existing_plans)
    })
    cached_drivers = get_available_drivers(depot_id)
    if not cached_drivers:
        log_circuit("No available drivers found", {"depot_id": depot_id})
        return None
    for plan in existing_plans:
        starts = plan.get("starts", {})
        date_matches = (
            starts.get("day") == day and
            starts.get("month") == month and
            starts.get("year") == year
        )
        if depot_id is not None:
            depot_matches = (plan.get("depot") == depot_id)
        else:
            depot_matches = (plan.get("depot") is None)
        if date_matches and depot_matches:
            if plan.get("distributed", False) or plan.get("locked", False):
                continue
            existing_drivers = set(plan.get("drivers", []))
            new_driver_ids = {driver["id"] for driver in cached_drivers}
            if not new_driver_ids.issubset(existing_drivers):
                all_drivers = list(existing_drivers.union(new_driver_ids))
                update_payload = {"drivers": all_drivers}
                try:
                    httpx.patch(f"{CIRCUIT_BASE}/{plan['id']}", headers=HEADERS, json=update_payload)
                    log_circuit("Updated plan with additional drivers", {"plan_id": plan["id"], "drivers": all_drivers})
                except Exception as e:
                    log_circuit("Failed to update plan drivers", {"plan_id": plan["id"], "error": str(e)})
            return plan["id"]
    day_name = dt.strftime("%A")
    unique_title = f"Optimized Route Plan for {day_name}, {work_date}"
    payload = {
        "title": unique_title,
        "starts": {"day": day, "month": month, "year": year},
        "drivers": [driver["id"] for driver in cached_drivers]
    }
    if depot_id:
        payload["depot"] = depot_id
    log_circuit("Creating plan with drivers", payload)
    res2 = httpx.post(f"{CIRCUIT_BASE}/plans", headers=HEADERS, json=payload)
    log_circuit("Plan creation response", {"status": res2.status_code, "body": res2.text, "depot_id": depot_id})
    res2.raise_for_status()
    pid = res2.json().get("id")
    log_circuit("Created plan", res2.json())
    return pid


def optimize_plan(plan_id: str) -> dict:
    url = f"{CIRCUIT_BASE}/{plan_id}:optimize"
    
    payload = {}
    
    try:
        res = httpx.post(url, headers=HEADERS, json=payload, timeout=30.0)
        res.raise_for_status()
        optimization_data = res.json()
        log_circuit("Plan optimization started", {"plan_id": plan_id, "response": optimization_data})
        
        if optimization_data.get("id"):
            optimization_id = optimization_data["id"]
            return wait_for_optimization_completion(optimization_id)
        
        return {"success": True, "optimization": optimization_data}
        
    except httpx.HTTPStatusError as e:
        error_detail = {"status": e.response.status_code, "body": e.response.text, "plan_id": plan_id}
        log_circuit("Error optimizing plan", error_detail)
        
        # Handle rate limiting
        if e.response.status_code == 429:
            log_circuit("Rate limit hit, waiting before retry", {"plan_id": plan_id})
            time.sleep(10)  # Wait longer
            # Try once more immediately
            try:
                res_retry = httpx.post(url, headers=HEADERS, json=payload, timeout=30.0)
                res_retry.raise_for_status()
                optimization_data = res_retry.json()
                log_circuit("Plan optimization succeeded on retry", {"plan_id": plan_id})
                
                if optimization_data.get("id"):
                    return wait_for_optimization_completion(optimization_data["id"])
                return {"success": True, "optimization": optimization_data}
            except:
                return {"success": False, "error": "Rate limited", "retry_after": 10}
        
        if e.response.status_code == 409:
            response_text = e.response.text.lower()
            if "already optimized" in response_text or "optimization" in response_text:
                log_circuit("Plan already optimized", {"plan_id": plan_id})
                return {"success": True, "message": "Plan already optimized"}
        
        return {"success": False, "error": f"HTTP {e.response.status_code}: {e.response.text}"}
    except Exception as e:
        log_circuit("Error optimizing plan", {"plan_id": plan_id, "error": str(e)})
        return {"success": False, "error": str(e)}

def wait_for_optimization_completion(optimization_id: str, max_wait_time: int = 300) -> dict:
    start_time = time.time()
    while time.time() - start_time < max_wait_time:
        try:
            res = httpx.get(f"{CIRCUIT_BASE}/{optimization_id}", headers=HEADERS)
            res.raise_for_status()
            optimization_status = res.json()
            
            if optimization_status.get("done", False):
                log_circuit("Optimization completed", {"optimization_id": optimization_id, "result": optimization_status})
                return {"success": True, "optimization": optimization_status}
            
            log_circuit("Optimization in progress", {"optimization_id": optimization_id, "status": optimization_status.get("type", "unknown")})
            time.sleep(10)
            
        except Exception as e:
            log_circuit("Error checking optimization status", {"optimization_id": optimization_id, "error": str(e)})
            return {"success": False, "error": str(e)}
    
    log_circuit("Optimization timeout", {"optimization_id": optimization_id})
    return {"success": False, "error": "Optimization timeout"}

def distribute_plan(plan_id: str) -> dict:
    url = f"{CIRCUIT_BASE}/{plan_id}:distribute"
    payload = {}  # Always send an empty JSON body
    try:
        res = httpx.post(url, headers=HEADERS, json=payload, timeout=30.0)
        res.raise_for_status()
        distribution_result = res.json()
        log_circuit("Plan distributed", {"plan_id": plan_id, "response": distribution_result})
        return {"success": True, "distribution": distribution_result}
    except httpx.HTTPStatusError as e:
        error_detail = {"status": e.response.status_code, "body": e.response.text, "plan_id": plan_id}
        log_circuit("Error distributing plan", error_detail)
        if e.response.status_code == 429:
            log_circuit("Rate limit hit on distribution", {"plan_id": plan_id})
            time.sleep(5)
            return {"success": False, "error": "Rate limited", "retry_after": 5}
        if e.response.status_code == 400:
            response_text = e.response.text.lower()
            if "already distributed" in response_text:
                return {"success": True, "message": "Plan already distributed"}
            elif "not yet optimized" in response_text:
                return {"success": False, "error": "Plan not yet optimized"}
        return {"success": False, "error": f"HTTP {e.response.status_code}: {e.response.text}"}
    except Exception as e:
        log_circuit("Error distributing plan", {"plan_id": plan_id, "error": str(e)})
        return {"success": False, "error": str(e)}

def get_plan_details(plan_id: str) -> dict:
    try:
        res = httpx.get(f"{CIRCUIT_BASE}/{plan_id}", headers=HEADERS)
        res.raise_for_status()
        return {"success": True, "plan": res.json()}
    except Exception as e:
        log_circuit("Error fetching plan details", {"plan_id": plan_id, "error": str(e)})
        return {"success": False, "error": str(e)}

def send_stop(order: dict) -> dict:
    from datetime import datetime
    plan_id = order.get("force_plan_id")
    if not plan_id:
        work_date = order.get("WorkDate", "")
        try:
            dt = datetime.strptime(work_date, "%d-%m-%Y")
            cd = dt.strftime("%Y-%m-%d")
        except Exception:
            cd = datetime.now().strftime("%Y-%m-%d")
        depot_id = get_depot_id_for_order(order)
        if not depot_id:
            log_circuit("No depot found for order, skipping stop creation", {"order": order})
            return {"success": False, "error": "No depot found for order"}
        plan_id = get_or_create_plan(work_date, depot_id)

    address_name_parts = [order.get("CustomerName", "").strip()]
    street = order.get("CustomerStreet", "").strip()
    if street:
        address_name_parts.append(street)
    city = order.get("CustomerCity", "").strip()
    if city:
        address_name_parts.append(city)
    zip_code = order.get("CustomerZIP", "").strip()
    if zip_code:
        address_name_parts.append(zip_code)
    country = order.get("CustomerCountry", "").strip()
    if country:
        address_name_parts.append(country)
    address_name = ", ".join([part for part in address_name_parts if part])
    addr = {
        "addressName": address_name,
        "addressLineOne": street,
        "city": city,
    }
    for field, key in [
        ("CustomerStreetNo", "addressLineTwo"),
        ("CustomerCountry", "state"),
        ("CustomerZIP", "zip"),
        ("CustomerCountry", "country")
    ]:
        value = order.get(field, "")
        if value:
            addr[key] = value
    lat, lng = order.get("CustomerLatitude"), order.get("CustomerLongitude")
    if lat and lng:
        try:
            addr["latitude"] = float(lat)
            addr["longitude"] = float(lng)
        except Exception:
            pass
    recipient = {}
    for field, key in [
        ("id", "externalId"),
        ("CustomerEmail", "email"),
        ("CustomerPhone", "phone"),
        ("CustomerName", "name")
    ]:
        value = order.get(field, "")
        if value:
            recipient[key] = str(value)
    order_info = {}
    products = [m.get("MaterialName", "") for m in order.get("Materials", []) if m.get("MaterialName", "")]
    if products:
        order_info["products"] = products
    for field, key in [
        ("OrderNr", "sellerOrderId"),
        ("CustomerNameInvoice", "sellerName")
    ]:
        value = order.get(field, "")
        if value:
            order_info[key] = value
    try:
        earliest_hour, earliest_min = map(int, order.get("WorkTime", "00:00").split(":"))
        latest_hour, latest_min = map(int, order.get("WorkEndTime", "00:00").split(":"))
    except Exception:
        earliest_hour = latest_hour = 0
        earliest_min = latest_min = 0
    try:
        duration = int(order.get("WorkDuration", 60))
    except Exception:
        duration = 60
    if duration < 1:
        duration = 1
    timing = {
        "earliestAttemptTime": {"hour": earliest_hour, "minute": earliest_min},
        "latestAttemptTime": {"hour": latest_hour, "minute": latest_min},
        "estimatedAttemptDuration": duration
    }
    payload = {
        "address": addr,
        "timing": timing,
        "activity": "delivery",
        "packageCount": 1,
    }
    if recipient:
        payload["recipient"] = recipient
    if order_info:
        payload["orderInfo"] = order_info
    notes = f"{order.get('CustomerRemark', '')} | {order.get('WorkDescription', '')} | {order.get('TypeOfWork', '')}"
    if notes:
        payload["notes"] = notes
    try:
        res = httpx.post(f"{CIRCUIT_BASE}/{plan_id}/stops", headers=HEADERS, json=payload)
        res.raise_for_status()
        stop_data = res.json()
        log_circuit("Stop created", stop_data)
        return {
            "success": True,
            "response": stop_data,
            "plan_id": plan_id
        }
    except httpx.HTTPStatusError as e:
        log_circuit("Error creating stop", {"status": e.response.status_code, "body": e.response.text})
        return {"success": False, "error": {"status": e.response.status_code, "body": e.response.text}}

def process_plan_optimization_and_distribution(plan_id: str, max_retries: int = 3) -> dict:
    log_circuit("Starting plan optimization and distribution", {"plan_id": plan_id})
    plan_details = get_plan_details(plan_id)
    if not plan_details.get("success"):
        return {"success": False, "error": "Failed to fetch plan details"}
    plan = plan_details["plan"]
    if plan.get("distributed", False):
        log_circuit("Plan already distributed", {"plan_id": plan_id})
        return {"success": True, "message": "Plan already distributed", "plan": plan}
    if plan.get("locked", False):
        log_circuit("Plan is locked, cannot optimize/distribute", {"plan_id": plan_id})
        return {"success": False, "error": "Plan is locked, cannot optimize/distribute"}
    drivers = plan.get("drivers", [])
    if not drivers:
        log_circuit("Plan has no drivers, cannot optimize/distribute", {"plan_id": plan_id})
        return {"success": False, "error": "Plan has no drivers assigned"}
    optimization_status = plan.get("optimization", "")
    optimized = plan.get("optimized", False)
    log_circuit("Plan optimization status", {"plan_id": plan_id, "optimization": optimization_status, "optimized": optimized})
    if not optimized and optimization_status not in ["optimized", "completed"]:
        log_circuit("Plan not optimized, starting optimization", {"plan_id": plan_id})
    for attempt in range(max_retries):
        current_plan = get_plan_details(plan_id)
        if current_plan.get("success"):
            plan_status = current_plan["plan"]
            if plan_status.get("distributed", False):
                log_circuit("Plan already distributed (in retry loop)", {"plan_id": plan_id})
                return {"success": True, "message": "Plan already distributed", "plan": plan_status}
            if plan_status.get("locked", False):
                log_circuit("Plan is locked (in retry loop), cannot optimize/distribute", {"plan_id": plan_id})
                return {"success": False, "error": "Plan is locked, cannot optimize/distribute"}
            if not plan_status.get("optimized", False):
                log_circuit("Plan not optimized before distribution, forcing optimization", {"plan_id": plan_id})
                throttle_optimization()
                opt_result = optimize_plan(plan_id)
                if not opt_result.get("success"):
                    return {"success": False, "error": f"Required optimization failed: {opt_result.get('error')}"}
                optimization_id = opt_result.get("optimization", {}).get("id")
                if optimization_id:
                    wait_result = wait_for_optimization_completion(optimization_id)
                    if not wait_result.get("success"):
                        return {"success": False, "error": f"Optimization did not complete: {wait_result.get('error')}"}
                else:
                    for _ in range(30):
                        time.sleep(10)
                        plan_check = get_plan_details(plan_id)
                        if plan_check.get("success") and plan_check["plan"].get("optimized", False):
                            break
                    else:
                        return {"success": False, "error": "Plan did not reach optimized state in time"}
                time.sleep(2)
        distribution_result = distribute_plan(plan_id)
        if distribution_result.get("success"):
            final_plan = get_plan_details(plan_id)
            return {
                "success": True,
                "optimization": {"success": True, "message": "Plan optimized"},
                "distribution": distribution_result,
                "final_plan": final_plan.get("plan") if final_plan.get("success") else None
            }
        else:
            error_msg = distribution_result.get("error", "")
            if "already distributed" in str(error_msg).lower():
                log_circuit("Plan was already distributed", {"plan_id": plan_id})
                return {"success": True, "message": "Plan was already distributed"}
            elif "not optimized" in str(error_msg).lower() or "plan_not_optimized" in str(error_msg).lower():
                log_circuit("Plan not optimized, forcing optimization before retry", {"plan_id": plan_id})
                throttle_optimization()
                opt_result = optimize_plan(plan_id)
                if not opt_result.get("success"):
                    return {"success": False, "error": f"Required optimization failed: {opt_result.get('error')}"}
                optimization_id = opt_result.get("optimization", {}).get("id")
                if optimization_id:
                    wait_result = wait_for_optimization_completion(optimization_id)
                    if not wait_result.get("success"):
                        return {"success": False, "error": f"Optimization did not complete: {wait_result.get('error')}"}
                else:
                    for _ in range(30):
                        time.sleep(10)
                        plan_check = get_plan_details(plan_id)
                        if plan_check.get("success") and plan_check["plan"].get("optimized", False):
                            break
                    else:
                        return {"success": False, "error": "Plan did not reach optimized state in time"}
                time.sleep(2)
                continue
            elif "Rate limited" in str(error_msg):
                if attempt < max_retries - 1:
                    wait_time = 5 * (attempt + 1)
                    log_circuit(f"Rate limited on distribution, waiting {wait_time}s before retry {attempt + 1}", {"plan_id": plan_id})
                    time.sleep(wait_time)
                    continue
                else:
                    return {"success": False, "error": f"Distribution failed after {max_retries} retries: {error_msg}"}
            else:
                return {"success": False, "error": f"Distribution failed: {error_msg}"}
    else:
        log_circuit("Plan already optimized", {"plan_id": plan_id})
    for attempt in range(max_retries):
        distribution_result = distribute_plan(plan_id)
        if distribution_result.get("success"):
            final_plan = get_plan_details(plan_id)
            return {
                "success": True,
                "optimization": {"success": True, "message": "Plan optimized"},
                "distribution": distribution_result,
                "final_plan": final_plan.get("plan") if final_plan.get("success") else None
            }
        else:
            error_msg = distribution_result.get("error", "")
            if "already distributed" in str(error_msg).lower():
                log_circuit("Plan was already distributed", {"plan_id": plan_id})
                return {"success": True, "message": "Plan was already distributed"}
            elif "Rate limited" in str(error_msg):
                if attempt < max_retries - 1:
                    wait_time = 5 * (attempt + 1)
                    log_circuit(f"Rate limited on distribution, waiting {wait_time}s before retry {attempt + 1}", {"plan_id": plan_id})
                    time.sleep(wait_time)
                    continue
                else:
                    log_circuit("Max retries reached for distribution", {"plan_id": plan_id, "error": error_msg})
                    return {"success": False, "error": f"Distribution failed after {max_retries} retries: {error_msg}"}
            else:
                return {"success": False, "error": f"Distribution failed: {error_msg}"}
    return {"success": False, "error": "Unexpected error in optimization and distribution"}

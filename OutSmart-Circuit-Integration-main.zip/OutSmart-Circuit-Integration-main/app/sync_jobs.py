import time
from collections import defaultdict
from .outsmart_client import (
    get_latest_workorders_by_execution,
    get_all_new_workorders,
    get_all_unsynced_workorders,
    get_workorders_by_date_range,
    get_failed_workorders,
    update_outsmart_status,
    mark_workorder_synced
)
from .circuit_client import (
    get_or_create_plan,
    send_stop,
    process_plan_optimization_and_distribution,
    log_circuit,
    get_depot_name_by_id
)

def get_validated_depot_id(employee_number, city, customer_name):
    depot_id = None
    depot_source = "none"
    
    if employee_number:
        from .driver_employee_cache import update_cache_if_needed, get_depot_by_employee_email
        _, employees = update_cache_if_needed()
        employee_email = ""
        employee_name = ""
        
        for emp in employees:
            if str(emp.get("number")) == str(employee_number):
                employee_email = (emp.get("email") or "").strip()
                employee_name = f"{emp.get('firstname','')} {emp.get('lastname','')}".strip()
                break
                
        if employee_email:
            depot_id = get_depot_by_employee_email(employee_email)
            if depot_id:
                depot_source = f"employee_email:{employee_email}"
    
    if not depot_id:
        try:
            import httpx
            from .config import CIRCUIT_BASE, CIRCUIT_API_KEY
            headers = {"Authorization": f"Bearer {CIRCUIT_API_KEY}", "Content-Type": "application/json"}
            res = httpx.get(f"{CIRCUIT_BASE}/depots", headers=headers, timeout=30)
            
            if res.status_code == 200:
                depots = res.json().get("depots", [])
                city_lower = city.lower()
                
                if "lisboa" in city_lower or "porto" in city_lower or "lisbon" in city_lower:
                    for depot in depots:
                        if "lisboa" in depot.get("name", "").lower():
                            depot_id = depot["id"]
                            depot_source = f"city_lisboa:{city}"
                            break
                else:
                    for depot in depots:
                        if "maia" in depot.get("name", "").lower():
                            depot_id = depot["id"]
                            depot_source = f"city_maia:{city}"
                            break
                
                if not depot_id and depots:
                    depot_id = depots[0]["id"]
                    depot_source = f"fallback_first:{depots[0].get('name','unknown')}"
                    
        except Exception as e:
            log_circuit("Error in depot fallback", {"error": str(e)})
    
    return depot_id, depot_source

def process_orders_batch(orders):
    plan_groups = defaultdict(list)
    
    for order in orders:
        work_date = order.get("WorkDate", "")
        employee_number = order.get("EmployeeNumber", "")
        city = order.get("CustomerCity", "")
        customer_name = order.get("CustomerName", "")
        
        if not work_date:
            log_circuit("Missing WorkDate in order, falling back to CreationDate", {
                "order_id": order.get("id"), 
                "CreationDate": order.get("CreationDate", "")
            })
            try:
                cd = order.get("CreationDate", "").split()[0]
                from datetime import datetime
                dt = datetime.strptime(cd, "%Y-%m-%d")
                work_date = dt.strftime("%d-%m-%Y")
            except Exception:
                from datetime import datetime
                work_date = datetime.now().strftime("%d-%m-%Y")
        
        depot_id, depot_source = get_validated_depot_id(employee_number, city, customer_name)
        
        if not depot_id:
            log_circuit("No depot found for order, skipping", {
                "order_id": order.get("id"),
                "employee_number": employee_number,
                "customer_name": customer_name,
                "city": city
            })
            continue
        
        log_circuit("Order depot assignment", {
            "order_id": order.get("id"),
            "depot_id": depot_id,
            "depot_name": get_depot_name_by_id(depot_id),
            "source": depot_source
        })
        
        order["force_depot_id"] = depot_id
        plan_groups[(work_date, depot_id)].append(order)
    
    results = []
    plan_processed = set()
    processed_count = 0
    
    for (work_date, depot_id), group_orders in plan_groups.items():
        try:
            depot_name = get_depot_name_by_id(depot_id) or "Unknown Depot"
            plan_id = get_or_create_plan(work_date, depot_id)
            if not plan_id:
                log_circuit("Failed to create/find plan; skipping group", {
                    "work_date": work_date,
                    "depot_id": depot_id
                })
                for order in group_orders:
                    results.append({
                        "success": False,
                        "order_id": order.get("id"),
                        "error": "No plan available"
                    })
                    update_outsmart_status(order.get("id"), "CIRCUIT_ERROR")
                continue

            stop_ids = []
            for order in group_orders:
                resp = send_stop({**order, "force_plan_id": plan_id})
                if resp.get("success"):
                    stop_id = resp["response"].get("id")
                    stop_ids.append(stop_id)
                    customer_name = order.get("CustomerName", "Unknown Customer")
                    print(f"✅ Stop sent for workorder {order.get('id')} ({customer_name})")
                    print(f"  🏢 Depot: {depot_name}")
                    print(f"  📍 stop_id={stop_id}")
                    print(f"  📋 plan_id={plan_id}")
                    mark_workorder_synced(order.get("id"))
                    update_outsmart_status(order.get("id"), "SENT_TO_CIRCUIT")
                    results.append({
                        "success": True,
                        "order_id": order.get("id"),
                        "plan_id": plan_id,
                        "stop_id": stop_id
                    })
                else:
                    print(f"❌ Failed to send stop for workorder {order.get('id')}: {resp.get('error')}")
                    results.append({
                        "success": False,
                        "order_id": order.get("id"),
                        "error": resp.get("error")
                    })
                    time.sleep(0.22)

            if plan_id not in plan_processed:
                if processed_count > 0:
                    delay = min(10, processed_count * 2)
                    print(f"⏳ Waiting {delay} seconds before processing next plan to avoid rate limits...")
                    time.sleep(delay)
                print(f"🚀 Processing optimization and distribution for plan {plan_id} ({depot_name}) with {len(stop_ids)} stops")
                plan_processed.add(plan_id)
                try:
                    plan_result = process_plan_optimization_and_distribution(plan_id)
                    if plan_result.get("success"):
                        print(f"✅ Plan {plan_id} ({depot_name}) optimized and distributed successfully")
                        for result in results:
                            if result.get("plan_id") == plan_id and result.get("success"):
                                order_id = result.get("order_id")
                                update_outsmart_status(order_id, "OPTIMIZED_AND_DISTRIBUTED")
                    else:
                        error_msg = plan_result.get("error", "Unknown error")
                        print(f"❌ Failed to optimize/distribute plan {plan_id} ({depot_name}): {error_msg}")
                        if "already distributed" in str(error_msg).lower():
                            print(f"ℹ️ Plan {plan_id} ({depot_name}) was already distributed, marking as successful")
                            for result in results:
                                if result.get("plan_id") == plan_id and result.get("success"):
                                    order_id = result.get("order_id")
                                    update_outsmart_status(order_id, "OPTIMIZED_AND_DISTRIBUTED")
                        else:
                            for result in results:
                                if result.get("plan_id") == plan_id and result.get("success"):
                                    order_id = result.get("order_id")
                                    update_outsmart_status(order_id, "CIRCUIT_ERROR")
                except Exception as e:
                    print(f"❌ Error processing plan {plan_id} ({depot_name}): {e}")
                    for result in results:
                        if result.get("plan_id") == plan_id and result.get("success"):
                            order_id = result.get("order_id")
                            update_outsmart_status(order_id, "CIRCUIT_ERROR")
            
            processed_count += 1

        except Exception as e:
            print(f"❌ Error processing group (work_date={work_date}, depot={depot_id}): {e}")
            for order in group_orders:
                results.append({
                    "success": False,
                    "order_id": order.get("id"),
                    "error": str(e)
                })
    
    return results

def sync_routes():
    print("🚀 Starting Outsmart → Circuit integration (Production Mode)")
    print("📅 Fetching today's workorders with status=Opgehaald...")
    
    orders = get_latest_workorders_by_execution()
    if not orders:
        print("✅ No workorders to process")
        return
    
    print(f"📦 Processing {len(orders)} workorders...")
    results = process_orders_batch(orders)
    
    successful = sum(1 for r in results if r.get("success"))
    failed = len(results) - successful
    
    print(f"✅ Sync completed: {successful} successful, {failed} failed")

def sync_all_unsynced_routes():
    print("🚀 Starting Outsmart → Circuit integration (Dev/Debug Mode)")
    print("📅 Fetching all unsynced workorders with status=Opgehaald...")
    
    orders = get_all_unsynced_workorders()
    if not orders:
        print("✅ No unsynced workorders to process")
        return
    
    print(f"📦 Processing {len(orders)} unsynced workorders...")
    results = process_orders_batch(orders)
    
    successful = sum(1 for r in results if r.get("success"))
    failed = len(results) - successful
    
    print(f"✅ Sync completed: {successful} successful, {failed} failed")

def sync_specific_date_range(start_date: str, end_date: str = None):
    print(f"🚀 Starting Outsmart → Circuit integration for date range")
    print(f"📅 Fetching workorders from {start_date} to {end_date or start_date}...")
    
    orders = get_workorders_by_date_range(start_date, end_date)
    if not orders:
        print("✅ No workorders found for the specified date range")
        return
    
    print(f"📦 Processing {len(orders)} workorders...")
    results = process_orders_batch(orders)
    
    successful = sum(1 for r in results if r.get("success"))
    failed = len(results) - successful
    
    print(f"✅ Sync completed: {successful} successful, {failed} failed")

def retry_failed_orders():
    print("🚀 Starting retry of failed workorders...")
    
    orders = get_failed_workorders()
    if not orders:
        print("✅ No failed workorders to retry")
        return
    
    print(f"📦 Retrying {len(orders)} failed workorders...")
    results = process_orders_batch(orders)
    
    successful = sum(1 for r in results if r.get("success"))
    failed = len(results) - successful
    
    print(f"✅ Retry completed: {successful} successful, {failed} failed")

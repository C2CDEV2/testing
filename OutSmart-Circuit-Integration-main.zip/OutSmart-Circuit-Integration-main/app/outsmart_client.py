import httpx, os
from datetime import datetime, timedelta
from .config import OUTSMART_BASE_URL, OUTSMART_BEARER

HEADERS = {
    "Authorization": f"Bearer {OUTSMART_BEARER}",
    "Accept": "*/*"
}

LOG_FILE = "app/logs/outsmart_fetch.txt"

def log_fetch(latest_dt, orders):
    os.makedirs(os.path.dirname(LOG_FILE), exist_ok=True)
    with open(LOG_FILE, "a", encoding="utf-8") as f:
        f.write(f"[{datetime.now().isoformat()}] Latest Execution: {latest_dt.strftime('%d-%m-%Y %H:%M')}, "
                f"Orders: {len(orders)}, OrderNr: {[o.get('OrderNr') for o in orders]}\n")

def get_latest_workorders_by_execution():
    """Fetch today's workorders with status=Opgehaald based on Execution Date and Time"""
    try:
        today = datetime.now().strftime("%Y-%m-%d")
        url = f"{OUTSMART_BASE_URL}/GetWorkorders/?token=&software_token=&status=Opgehaald&update_status=false&key=WorkDate&value={today}&operator=eq"
        
        print(f"[🔍] Fetching workorders with URL: {url}")
        
        response = httpx.get(url, headers=HEADERS, timeout=30)
        response.raise_for_status()
        data = response.json().get("response", [])

        if not isinstance(data, list) or len(data) == 0:
            print("[⚠️] No workorders with status=Opgehaald found for today.")
            return []

        print(f"[📊] Raw API response: {len(data)} workorders received")
        
        # Filter by WorkDate and WorkTime (ED&T)
        today_str = datetime.now().strftime("%d-%m-%Y")
        valid_orders = []
        
        for row in data:
            wd, wt = row.get("WorkDate"), row.get("WorkTime")
            if not wd or not wt:
                print(f"[⚠️] Skipping order {row.get('id')} - missing WorkDate or WorkTime")
                continue
            
            if wd.strip() != today_str:
                print(f"[⚠️] Skipping order {row.get('id')} - WorkDate {wd} != today {today_str}")
                continue
            
            try:
                execution_start = datetime.strptime(f"{wd} {wt}", "%d-%m-%Y %H:%M")
                valid_orders.append(row)
                print(f"[✅] Valid order {row.get('id')} - WorkDate: {wd}, WorkTime: {wt}")
            except ValueError as e:
                print(f"[❌] Skipping order {row.get('id')} - invalid date format: {e}")
                continue

        if not valid_orders:
            print("[⚠️] No valid workorders with proper ED&T for today found.")
            return []

        print(f"[✅] Found {len(valid_orders)} workorders with status=Opgehaald for today's ED&T")
        
        # Return all valid orders, not just the latest
        return valid_orders
        
    except Exception as e:
        print(f"[❌] Error fetching today's workorders: {e}")
        return []

def get_workorders_for_date(workdate):
    """Fetch all workorders with status=Opgehaald for a specific WorkDate (YYYY-MM-DD)"""
    try:
        # Convert DD-MM-YYYY to YYYY-MM-DD for API
        try:
            dt = datetime.strptime(workdate, "%d-%m-%Y")
            api_date = dt.strftime("%Y-%m-%d")
        except ValueError:
            print(f"[❌] Invalid date format: {workdate}")
            return []
        
        url = f"{OUTSMART_BASE_URL}/GetWorkorders/?token=&software_token=&status=Opgehaald&update_status=false&key=WorkDate&value={api_date}&operator=eq"
        
        response = httpx.get(url, headers=HEADERS, timeout=30)
        response.raise_for_status()
        data = response.json().get("response", [])
        
        print(f"[✅] Found {len(data)} workorders with status=Opgehaald for {workdate}")
        return data
        
    except Exception as e:
        print(f"[❌] Error fetching workorders for date {workdate}: {e}")
        return []

def get_workorders_by_date_range(start_date: str, end_date: str = None):
    """Fetch workorders for a date range. Dates should be in YYYY-MM-DD format."""
    try:
        start_dt = datetime.strptime(start_date, "%Y-%m-%d")
        end_dt = datetime.strptime(end_date, "%Y-%m-%d") if end_date else start_dt
        
        all_orders = []
        current_dt = start_dt
        
        while current_dt <= end_dt:
            workdate = current_dt.strftime("%d-%m-%Y")
            orders = get_workorders_for_date(workdate)
            all_orders.extend(orders)
            current_dt += timedelta(days=1)
        
        print(f"[✅] Found {len(all_orders)} total workorders for date range {start_date} to {end_dt.strftime('%Y-%m-%d')}")
        return all_orders
        
    except ValueError as e:
        print(f"[❌] Invalid date format: {e}")
        return []
    except Exception as e:
        print(f"[❌] Error fetching workorders by date range: {e}")
        return []

def update_outsmart_status(order_id: str, status: str) -> bool:
    """Update workorder status in Outsmart"""
    try:
        url = f"{OUTSMART_BASE_URL}/UpdateWorkorder/"
        payload = {"workorder_no": order_id, "status": status}
        resp = httpx.post(url, headers=HEADERS, json=payload, timeout=30)
        return resp.status_code == 200
    except Exception as e:
        print(f"[❌] Error updating workorder status: {e}")
        return False

def get_all_new_workorders():
    """Fetch all workorders with status=Opgehaald for today's execution date that have not been synced yet."""
    try:
        today = datetime.now().strftime("%d-%m-%Y")
        all_orders = get_workorders_for_date(today)
        
        synced_ids = set()
        try:
            with open("app/logs/synced_workorders.txt", "r", encoding="utf-8") as f:
                synced_ids = set(line.strip() for line in f if line.strip())
        except FileNotFoundError:
            pass
        
        new_orders = [o for o in all_orders if str(o.get("id")) not in synced_ids]
        print(f"[✅] Found {len(new_orders)} new unsynced workorders for today")
        return new_orders
        
    except Exception as e:
        print(f"[❌] Error fetching new workorders: {e}")
        return []

def mark_workorder_synced(order_id):
    """Mark a workorder as synced"""
    try:
        with open("app/logs/synced_workorders.txt", "a", encoding="utf-8") as f:
            f.write(f"{order_id}\n")
    except Exception as e:
        print(f"[❌] Error marking workorder as synced: {e}")

def get_all_unsynced_workorders():
    """Fetch all workorders with status=Opgehaald from Outsmart that have not been synced yet (no date filter)."""
    try:
        url = f"{OUTSMART_BASE_URL}/GetWorkorders/?token=&software_token=&update_status=false"
        response = httpx.get(url, headers=HEADERS, timeout=30)
        response.raise_for_status()
        all_orders = response.json().get("response", [])
        
        synced_ids = set()
        try:
            with open("app/logs/synced_workorders.txt", "r", encoding="utf-8") as f:
                synced_ids = set(line.strip() for line in f if line.strip())
        except FileNotFoundError:
            pass
        
        new_orders = [o for o in all_orders if str(o.get("id")) not in synced_ids]
        print(f"[✅] Found {len(new_orders)} unsynced workorders with status=Opgehaald")
        return new_orders
        
    except Exception as e:
        print(f"[❌] Error fetching unsynced workorders: {e}")
        return []

def get_failed_workorders():
    """Fetch workorders that have failed to sync (for retry functionality)."""
    try:
        url = f"{OUTSMART_BASE_URL}/GetWorkorders/?token=&software_token=&update_status=false"
        response = httpx.get(url, headers=HEADERS, timeout=30)
        response.raise_for_status()
        all_orders = response.json().get("response", [])
        
        failed_orders = []
        for order in all_orders:
            status = order.get("status", "").lower()
            if "error" in status or "failed" in status or "circuit_error" in status:
                failed_orders.append(order)
        
        print(f"[✅] Found {len(failed_orders)} failed workorders")
        return failed_orders
        
    except Exception as e:
        print(f"[❌] Error fetching failed workorders: {e}")
        return []

import httpx
from datetime import datetime
from .config import OUTSMART_BASE_URL, OUTSMART_BEARER

HEADERS = {
    "Authorization": f"Bearer {OUTSMART_BEARER}",
    "Accept": "*/*"
}

def get_latest_workorder_by_creation():
    url = f"{OUTSMART_BASE_URL}/GetWorkorders/?software_token=&update_status=false"
    response = httpx.get(url, headers=HEADERS, timeout=10)
    response.raise_for_status()

    data = response.json().get("response", [])

    if not isinstance(data, list) or len(data) == 0:
        print("[⚠️] API returned no workorders.")
        return None

    # Filter orders with valid CreationDate
    dated_orders = []
    for row in data:
        cd = row.get("CreationDate")
        if cd and isinstance(cd, str):
            try:
                created_at = datetime.strptime(cd, "%Y-%m-%d %H:%M:%S")
                dated_orders.append((created_at, row))
            except ValueError:
                continue

    if not dated_orders:
        print("[⚠️] No valid 'CreationDate' entries found.")
        return None

    # Return the latest order only
    latest_order = max(dated_orders, key=lambda x: x[0])[1]
    return latest_order

def get_workorders_for_date(workdate):
    """Fetch all workorders with a specific WorkDate (DD-MM-YYYY)"""
    url = (
        f"{OUTSMART_BASE_URL}/GetWorkorders/"
        f"?software_token=&update_status=false"
        f"&key=WorkDate&value={workdate}&operator=eq"
    )
    response = httpx.get(url, headers=HEADERS, timeout=10)
    response.raise_for_status()
    return response.json().get("response", [])

def update_outsmart_status(order_id: str, status: str) -> bool:
    url = f"{OUTSMART_BASE_URL}/UpdateWorkorder/"
    payload = {"workorder_no": order_id, "status": status}
    resp = httpx.post(url, headers=HEADERS, json=payload)
    return resp.status_code == 200

def get_all_new_workorders():
    """Fetch all workorders for today that have not been synced yet."""
    from datetime import datetime
    today = datetime.now().strftime("%d-%m-%Y")
    all_orders = get_workorders_for_date(today)
    synced_ids = set()
    try:
        with open("app/logs/synced_workorders.txt", "r", encoding="utf-8") as f:
            synced_ids = set(line.strip() for line in f if line.strip())
    except FileNotFoundError:
        pass
    new_orders = [o for o in all_orders if str(o.get("id")) not in synced_ids]
    return new_orders

def mark_workorder_synced(order_id):
    with open("app/logs/synced_workorders.txt", "a", encoding="utf-8") as f:
        f.write(f"{order_id}\n")

def get_all_unsynced_workorders():
    """Fetch all workorders from Outsmart that have not been synced yet (no date filter)."""
    url = f"{OUTSMART_BASE_URL}/GetWorkorders/?software_token=&update_status=false"
    response = httpx.get(url, headers=HEADERS, timeout=10)
    response.raise_for_status()
    all_orders = response.json().get("response", [])
    synced_ids = set()
    try:
        with open("app/logs/synced_workorders.txt", "r", encoding="utf-8") as f:
            synced_ids = set(line.strip() for line in f if line.strip())
    except FileNotFoundError:
        pass
    new_orders = [o for o in all_orders if str(o.get("id")) not in synced_ids]
    return new_orders
from celery import Celery
from celery.schedules import crontab
from app.config import REDIS_URL

def make_app():
    return Celery("tasks", broker=REDIS_URL)

app = make_app()
app.autodiscover_tasks()

app.conf.beat_schedule = {
    'sync-every-morning': {
        'task': 'tasks.daily_route_sync',
        'schedule': crontab(hour=6, minute=0),
    },
}
import httpx, os, json, time
from datetime import datetime, timedelta
from .config import OUTSMART_BASE_URL, OUTSMART_BEARER, CIRCUIT_BASE, CIRCUIT_API_KEY

OUTSMART_HEADERS = {"Authorization": f"Bearer {OUTSMART_BEARER}", "Accept": "*/*"}
CIRCUIT_HEADERS = {"Authorization": f"Bearer {CIRCUIT_API_KEY}", "Content-Type": "application/json"}

CACHE_DIR = "app/logs"
DRIVERS_CACHE_FILE = f"{CACHE_DIR}/drivers.json"
EMPLOYEES_CACHE_FILE = f"{CACHE_DIR}/employees.json"
TIMESTAMP_FILE = f"{CACHE_DIR}/cache_timestamp.txt"
CACHE_DURATION_DAYS = 7

def get_driver_email_blocklist():
    """Emails to exclude from matching/distribution."""
    try:
        env_val = os.getenv("BLOCKED_DRIVER_EMAILS", "")
        env_blocked = {e.strip().lower() for e in env_val.split(",") if e.strip()}
        default_blocked = {"r.brito@airbel.pt", "dev@company.com", "test@company.com", "developer@test.com"}
        return default_blocked.union(env_blocked)
    except Exception:
        return {"r.brito@airbel.pt", "dev@company.com", "test@company.com", "developer@test.com"}

def ensure_cache_directory():
    """Ensure cache directory exists"""
    try:
        os.makedirs(CACHE_DIR, exist_ok=True)
        return True
    except Exception as e:
        print(f"[❌] Error creating cache directory: {e}")
        return False

def get_cache_timestamp():
    """Get the last cache update timestamp"""
    try:
        if os.path.exists(TIMESTAMP_FILE):
            with open(TIMESTAMP_FILE, 'r') as f:
                timestamp_str = f.read().strip()
                return datetime.fromisoformat(timestamp_str)
    except Exception as e:
        print(f"[⚠️] Error reading cache timestamp: {e}")
    return None

def update_cache_timestamp():
    """Update the cache timestamp to current time"""
    try:
        ensure_cache_directory()
        with open(TIMESTAMP_FILE, 'w') as f:
            f.write(datetime.now().isoformat())
        return True
    except Exception as e:
        print(f"[❌] Error updating cache timestamp: {e}")
        return False

def is_cache_expired():
    """Check if cache is expired (older than CACHE_DURATION_DAYS)"""
    try:
        last_update = get_cache_timestamp()
        if not last_update:
            return True
        expiry_date = last_update + timedelta(days=CACHE_DURATION_DAYS)
        return datetime.now() > expiry_date
    except Exception as e:
        print(f"[⚠️] Error checking cache expiry: {e}")
        return True

def is_cache_empty():
    """Check if cache files are empty or don't exist"""
    try:
        drivers_exist = os.path.exists(DRIVERS_CACHE_FILE) and os.path.getsize(DRIVERS_CACHE_FILE) > 0
        employees_exist = os.path.exists(EMPLOYEES_CACHE_FILE) and os.path.getsize(EMPLOYEES_CACHE_FILE) > 0
        return not (drivers_exist and employees_exist)
    except Exception:
        return True

def fetch_circuit_drivers():
    """Fetch all active drivers from Circuit API"""
    try:
        if not CIRCUIT_API_KEY:
            print("[❌] Circuit API key not configured")
            return []
        
        url = f"{CIRCUIT_BASE}/drivers?filter[active]=true&maxPageSize=50"
        response = httpx.get(url, headers=CIRCUIT_HEADERS, timeout=30)
        
        if response.status_code == 401:
            print("[❌] Circuit API authentication failed - check CIRCUIT_API_KEY")
            return []
        
        response.raise_for_status()
        data = response.json()
        
        drivers = []
        blocked = get_driver_email_blocklist()
        for driver in data.get("drivers", []):
            if driver.get("active", False):
                # Skip dev/test driver entries: no name or blocklisted emails
                name = (driver.get("name") or "").strip()
                email = (driver.get("email") or "").strip()
                if not name:
                    continue
                if email and email.strip().lower() in blocked:
                    continue
                driver_info = {
                    "name": name,
                    "email": email,
                    "active": driver.get("active", False),
                    "depots": driver.get("depots", [])
                }
                drivers.append(driver_info)
        
        print(f"[✅] Fetched {len(drivers)} active drivers from Circuit")
        return drivers
    except Exception as e:
        print(f"[❌] Error fetching Circuit drivers: {e}")
        return []

def fetch_outsmart_employees():
    """Fetch all employees from Outsmart API"""
    try:
        if not OUTSMART_BEARER:
            print("[❌] Outsmart Bearer token not configured")
            return []
        
        url = f"{OUTSMART_BASE_URL}/employees/?token=&software_token="
        response = httpx.get(url, headers=OUTSMART_HEADERS, timeout=30)
        
        if response.status_code == 401:
            print("[❌] Outsmart API authentication failed - check OUTSMART_BEARER")
            return []
        
        response.raise_for_status()
        data = response.json()
        
        employees = []
        for employee in data.get("response", []):
            employee_info = {
                "firstname": employee.get("firstname", ""),
                "lastname": employee.get("lastname", ""),
                "number": employee.get("number", ""),
                "email": employee.get("email", "")  # Add email field
            }
            if employee_info["number"]:  # Only include employees with valid numbers
                employees.append(employee_info)
        
        print(f"[✅] Fetched {len(employees)} employees from Outsmart")
        return employees
    except Exception as e:
        print(f"[❌] Error fetching Outsmart employees: {e}")
        return []

def save_cache_to_files(drivers, employees):
    """Save drivers and employees data to cache files"""
    try:
        ensure_cache_directory()
        
        # Save drivers cache
        with open(DRIVERS_CACHE_FILE, 'w', encoding='utf-8') as f:
            json.dump(drivers, f, indent=2, ensure_ascii=False)
        
        # Save employees cache
        with open(EMPLOYEES_CACHE_FILE, 'w', encoding='utf-8') as f:
            json.dump(employees, f, indent=2, ensure_ascii=False)
        
        # Update timestamp
        update_cache_timestamp()
        
        print(f"[✅] Cache updated successfully")
        return True
    except Exception as e:
        print(f"[❌] Error saving cache to files: {e}")
        return False

def load_cache_from_files():
    """Load drivers and employees data from cache files"""
    try:
        drivers = []
        employees = []
        
        # Load drivers cache
        if os.path.exists(DRIVERS_CACHE_FILE):
            with open(DRIVERS_CACHE_FILE, 'r', encoding='utf-8') as f:
                drivers = json.load(f)
        
        # Load employees cache
        if os.path.exists(EMPLOYEES_CACHE_FILE):
            with open(EMPLOYEES_CACHE_FILE, 'r', encoding='utf-8') as f:
                employees = json.load(f)
        
        return drivers, employees
    except Exception as e:
        print(f"[❌] Error loading cache from files: {e}")
        return [], []

def update_cache_if_needed():
    """Update cache if expired, empty, or doesn't exist"""
    try:
        # Force update if cache is empty
        if is_cache_empty():
            print("[🔄] Cache is empty, fetching fresh data...")
            drivers = fetch_circuit_drivers()
            employees = fetch_outsmart_employees()
            
            if drivers or employees:
                save_cache_to_files(drivers, employees)
                return drivers, employees
            else:
                print("[⚠️] Failed to fetch fresh data")
                return [], []
        
        # Check if cache is expired
        if is_cache_expired():
            print("[🔄] Cache expired, fetching fresh data...")
            drivers = fetch_circuit_drivers()
            employees = fetch_outsmart_employees()
            
            if drivers or employees:
                save_cache_to_files(drivers, employees)
                return drivers, employees
            else:
                print("[⚠️] Failed to fetch fresh data, using existing cache")
                return load_cache_from_files()
        else:
            print("[✅] Using existing cache")
            return load_cache_from_files()
    except Exception as e:
        print(f"[❌] Error updating cache: {e}")
        return load_cache_from_files()

def get_depot_by_employee_email(employee_email):
    """Match employee email directly to driver and return depot ID"""
    try:
        if not employee_email:
            print("[⚠️] No employee email provided")
            return None
        
        drivers, employees = update_cache_if_needed()
        
        if not drivers:
            print("[⚠️] No drivers available for matching")
            return None
        
        employee_email = employee_email.strip().lower()
        print(f"[🔍] Looking for driver with email: {employee_email}")
        if employee_email in get_driver_email_blocklist():
            print(f"[⚠️] Email {employee_email} is blocklisted for driver assignment")
            return None
        
        # Exact email match only (avoid mixing routes)
        matching_driver = next(
            (d for d in drivers if (d.get("email") or "").strip().lower() == employee_email),
            None
        )
        if not matching_driver:
            print(f"[⚠️] No driver with email {employee_email}")
            return None
        
        # Get depot from driver and validate against live depots
        depots = matching_driver.get("depots", [])
        if not depots:
            print(f"[⚠️] Driver {matching_driver.get('name')} has no assigned depots")
            return None

        depot_id = depots[0]
        try:
            res = httpx.get(f"{CIRCUIT_BASE}/depots", headers=CIRCUIT_HEADERS, timeout=30)
            res.raise_for_status()
            valid_ids = {d.get("id") for d in res.json().get("depots", [])}
            if depot_id not in valid_ids:
                print(f"[⚠️] Driver depot {depot_id} not in live depot list; skipping employee-based assignment")
                return None
        except Exception as e:
            print(f"[⚠️] Could not validate depot {depot_id}: {e}")
            # If validation fails, be safe and skip email-based depot assignment
            return None

        print(f"[✅] Matched {employee_email} → {matching_driver.get('name')} → {depot_id}")
        return depot_id
        
    except Exception as e:
        print(f"[❌] Error matching email to depot: {e}")
        return None

def get_driver_info_by_employee_email(employee_email):
    """Get driver information for an employee email"""
    try:
        if not employee_email:
            return None
        
        drivers, employees = update_cache_if_needed()
        
        employee_email = employee_email.strip().lower()
        if employee_email in get_driver_email_blocklist():
            return None
        
        # Exact email match only
        for driver in drivers:
            driver_email = (driver.get("email") or "").strip().lower()
            if driver_email and driver_email == employee_email:
                return {
                    "driver": driver,
                    "depot_id": driver.get("depots", [None])[0],
                    "match_type": "exact_email"
                }
        return None
    except Exception as e:
        print(f"[❌] Error getting driver info by email: {e}")
        return None

def get_depot_by_employee_number(employee_number):
    """Match employee number to driver and return depot ID using email matching"""
    try:
        if not employee_number:
            print("[⚠️] No employee number provided")
            return None
        
        drivers, employees = update_cache_if_needed()
        
        if not drivers or not employees:
            print("[⚠️] No drivers or employees available for matching")
            return None
        
        # Find employee by number
        employee = None
        for emp in employees:
            if str(emp.get("number", "")) == str(employee_number):
                employee = emp
                break
        
        if not employee:
            print(f"[⚠️] Employee with number {employee_number} not found")
            return None
        
        employee_email = employee.get("email", "").strip().lower()
        employee_name = f"{employee.get('firstname', '')} {employee.get('lastname', '')}".strip()
        
        print(f"[🔍] Looking for employee: {employee_name} (Email: {employee_email})")
        
        # Use the new email-based matching function
        return get_depot_by_employee_email(employee_email)
        
    except Exception as e:
        print(f"[❌] Error matching employee to depot: {e}")
        return None
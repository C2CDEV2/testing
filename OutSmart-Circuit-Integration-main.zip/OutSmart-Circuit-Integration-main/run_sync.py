from app.sync_jobs import sync_routes, sync_all_unsynced_routes, sync_specific_date_range, retry_failed_orders
import sys
from datetime import datetime

def print_usage():
    print("Usage:")
    print("  python run_sync.py                    - Sync new workorders")
    print("  python run_sync.py all                - Sync all unsynced workorders")
    print("  python run_sync.py date YYYY-MM-DD    - Sync specific date")
    print("  python run_sync.py range YYYY-MM-DD YYYY-MM-DD - Sync date range")
    print("  python run_sync.py retry              - Retry failed workorders")

if __name__ == "__main__":
    print("Starting Outsmart → Circuit integration with auto-optimization and distribution...")
    
    if len(sys.argv) == 1:
        sync_routes()
    elif len(sys.argv) == 2:
        command = sys.argv[1].lower()
        if command == "all":
            sync_all_unsynced_routes()
        elif command == "retry":
            retry_failed_orders()
        elif command == "help":
            print_usage()
        else:
            print(f"Unknown command: {command}")
            print_usage()
            sys.exit(1)
    elif len(sys.argv) == 3:
        command = sys.argv[1].lower()
        if command == "date":
            date = sys.argv[2]
            try:
                datetime.strptime(date, "%Y-%m-%d")
                sync_specific_date_range(date)
            except ValueError:
                print("Invalid date format. Use YYYY-MM-DD")
                sys.exit(1)
        else:
            print(f"Unknown command: {command}")
            print_usage()
            sys.exit(1)
    elif len(sys.argv) == 4:
        command = sys.argv[1].lower()
        if command == "range":
            start_date = sys.argv[2]
            end_date = sys.argv[3]
            try:
                datetime.strptime(start_date, "%Y-%m-%d")
                datetime.strptime(end_date, "%Y-%m-%d")
                sync_specific_date_range(start_date, end_date)
            except ValueError:
                print("Invalid date format. Use YYYY-MM-DD")
                sys.exit(1)
        else:
            print(f"Unknown command: {command}")
            print_usage()
            sys.exit(1)
    else:
        print("Too many arguments")
        print_usage()
        sys.exit(1)
    
    print("Integration complete. Check app/logs/ for detailed logs.")

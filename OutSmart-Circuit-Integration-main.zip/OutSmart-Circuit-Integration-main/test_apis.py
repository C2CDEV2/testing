#!/usr/bin/env python3
"""
Test script to check API connectivity and data
"""

import sys
import os
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

import httpx
from app.config import OUTSMART_BASE_URL, OUTSMART_BEARER, CIRCUIT_BASE, CIRCUIT_API_KEY

def test_circuit_api():
    """Test Circuit API connectivity"""
    print("🔌 Testing Circuit API...")
    print("=" * 50)
    
    if not CIRCUIT_API_KEY:
        print("❌ CIRCUIT_API_KEY not configured")
        return False
    
    headers = {"Authorization": f"Bearer {CIRCUIT_API_KEY}", "Content-Type": "application/json"}
    
    try:
        # Test depots endpoint
        print("1. Testing depots endpoint...")
        url = f"{CIRCUIT_BASE}/depots"
        response = httpx.get(url, headers=headers, timeout=30)
        print(f"   Status: {response.status_code}")
        
        if response.status_code == 200:
            data = response.json()
            depots = data.get("depots", [])
            print(f"   ✅ Found {len(depots)} depots")
            for depot in depots:
                print(f"      - {depot.get('name')} (ID: {depot.get('id')})")
        else:
            print(f"   ❌ Error: {response.text}")
            return False
        
        # Test drivers endpoint
        print("\n2. Testing drivers endpoint...")
        url = f"{CIRCUIT_BASE}/drivers?filter[active]=true&maxPageSize=50"
        response = httpx.get(url, headers=headers, timeout=30)
        print(f"   Status: {response.status_code}")
        
        if response.status_code == 200:
            data = response.json()
            drivers = data.get("drivers", [])
            active_drivers = [d for d in drivers if d.get("active", False)]
            print(f"   ✅ Found {len(drivers)} total drivers, {len(active_drivers)} active")
            for driver in active_drivers[:3]:  # Show first 3
                print(f"      - {driver.get('name')} (Email: {driver.get('email')})")
                print(f"        Depots: {driver.get('depots', [])}")
        else:
            print(f"   ❌ Error: {response.text}")
            return False
        
        return True
        
    except Exception as e:
        print(f"❌ Circuit API test failed: {e}")
        return False

def test_outsmart_api():
    """Test Outsmart API connectivity"""
    print("\n🔌 Testing Outsmart API...")
    print("=" * 50)
    
    if not OUTSMART_BEARER:
        print("❌ OUTSMART_BEARER not configured")
        return False
    
    headers = {"Authorization": f"Bearer {OUTSMART_BEARER}", "Accept": "*/*"}
    
    try:
        # Test employees endpoint
        print("1. Testing employees endpoint...")
        url = f"{OUTSMART_BASE_URL}/employees/?token=&software_token="
        response = httpx.get(url, headers=headers, timeout=30)
        print(f"   Status: {response.status_code}")
        
        if response.status_code == 200:
            data = response.json()
            employees = data.get("response", [])
            print(f"   ✅ Found {len(employees)} employees")
            for employee in employees[:3]:  # Show first 3
                print(f"      - {employee.get('firstname')} {employee.get('lastname')} (ID: {employee.get('number')})")
        else:
            print(f"   ❌ Error: {response.text}")
            return False
        
        # Test workorders endpoint
        print("\n2. Testing workorders endpoint...")
        from datetime import datetime
        today = datetime.now().strftime("%Y-%m-%d")
        url = f"{OUTSMART_BASE_URL}/GetWorkorders/?token=&software_token=&status=Opgehaald&update_status=false&key=WorkDate&value={today}&operator=eq"
        response = httpx.get(url, headers=headers, timeout=30)
        print(f"   Status: {response.status_code}")
        
        if response.status_code == 200:
            data = response.json()
            workorders = data.get("response", [])
            print(f"   ✅ Found {len(workorders)} workorders with status=Opgehaald for today")
            for workorder in workorders[:3]:  # Show first 3
                print(f"      - ID: {workorder.get('id')}")
                print(f"        Customer: {workorder.get('CustomerName')}")
                print(f"        WorkDate: {workorder.get('WorkDate')}")
                print(f"        WorkTime: {workorder.get('WorkTime')}")
                print(f"        EmployeeNumber: {workorder.get('EmployeeNumber')}")
                print(f"        Status: {workorder.get('Status')}")
        else:
            print(f"   ❌ Error: {response.text}")
            return False
        
        return True
        
    except Exception as e:
        print(f"❌ Outsmart API test failed: {e}")
        return False

def main():
    """Run all tests"""
    print("🧪 API Connectivity Test")
    print("=" * 60)
    
    circuit_ok = test_circuit_api()
    outsmart_ok = test_outsmart_api()
    
    print("\n" + "=" * 60)
    print("📊 Test Results:")
    print(f"   Circuit API: {'✅ OK' if circuit_ok else '❌ FAILED'}")
    print(f"   Outsmart API: {'✅ OK' if outsmart_ok else '❌ FAILED'}")
    
    if circuit_ok and outsmart_ok:
        print("\n🎉 All APIs are working correctly!")
    else:
        print("\n⚠️ Some APIs failed. Check your configuration.")
        if not circuit_ok:
            print("   - Check CIRCUIT_API_KEY in your .env file")
        if not outsmart_ok:
            print("   - Check OUTSMART_BEARER in your .env file")

if __name__ == "__main__":
    main()

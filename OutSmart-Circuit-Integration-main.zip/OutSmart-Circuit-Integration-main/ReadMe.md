<div align="center">
      <h1> 🚚 Outsmart ↔ Circuit Integration </h1>
</div>

<div align="center">

![Status](https://img.shields.io/badge/status-stable%20beta-brightgreen?style=for-the-badge&logo=checkmarx&logoColor=white)
![Production](https://img.shields.io/badge/production-ready-blue?style=for-the-badge&logo=vercel&logoColor=white)
![Tested](https://img.shields.io/badge/tests-passing-4caf50?style=for-the-badge&logo=pytest&logoColor=white)
![API Coverage](https://img.shields.io/badge/api-99%25%20covered-2196f3?style=for-the-badge&logo=swagger&logoColor=white)
![Sync Reliability](https://img.shields.io/badge/sync-robust-ff9800?style=for-the-badge&logo=sync&logoColor=white)
![Celery](https://img.shields.io/badge/celery-automated-37b24d?style=for-the-badge&logo=celery&logoColor=white)

</div>

---

## ✨ What This Actually Does

**Stop copying and pasting delivery data between systems.** This integration takes your work orders from Outsmart and automatically creates optimized delivery routes in Circuit — every single day, without you lifting a finger.

Think of it as your personal logistics assistant that never sleeps, never makes mistakes, and never forgets to sync your deliveries.

> **Why "Stable Beta"?**
> 
> It works rock-solid in production, but we're still listening to real users and adding cool features based on what you actually need (not what we think you need).

---

## 🎯 What Makes This Special

<div align="center">

**Daily Magic Happens Here** ✨

```
Every Morning at 6 AM (Tentative):
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│   Outsmart      │───▶│  This Thing     │───▶│    Circuit      │
│  Work Orders    │    │  Does Magic     │    │ Optimized Routes│
└─────────────────┘    └─────────────────┘    └─────────────────┘
      📋                       🤖                      🗺️
```

</div>

**Here's what actually happens behind the scenes:**

- **Automation (Adjustable):** Grabs all your new work orders from Outsmart
- **Smart Grouping:** Bundles everything for the same day into one delivery plan
- **Driver Assignment:** Automatically assigns all your available drivers
- **Route Magic:** Circuit figures out the most efficient routes
- **No Duplicates:** Remembers what it's already synced (your drivers won't get the same delivery twice)
- **Bulletproof Logging:** Records everything so you can see exactly what happened

---

## 🛠️ The Good Stuff

### Daily Automation That Just Works
Set it up once, forget about it forever. Every morning your Outsmart work orders magically appear as optimized routes in Circuit.

### Built for the Real World
- **Handles failures gracefully** - if something goes wrong, it tries again
- **Never creates duplicates** - each work order syncs exactly once
- **Logs everything** - you can see what happened and when
- **Works with your existing setup** - no need to change how you create work orders

### Your Drivers Will Love You
Instead of getting a random pile of deliveries, they get:
- **Optimized routes** that make sense geographically  
- **Automatic assignments** distributed fairly among the team
- **Everything in their Circuit mobile app** ready to go

### Easy to Customize
Need different driver assignments? Multiple depots? Custom routing logic? The code is written to handle these changes without breaking everything else.

---

## 🏗️ How It All Fits Together

```mermaid
flowchart TD
    A[📋 Outsmart Work Orders] -->|"Fetch new orders"| B[🤖 Integration Engine]
    B -->|"Create daily plan"| C[🗺️ Circuit API]
    B -->|"Add delivery stops"| C
    B -->|"Assign drivers"| C
    C -->|"Optimized routes"| D[📱 Driver Mobile Apps]
    B -->|"Keep detailed logs"| E[📄 Audit Trail]
    B -->|"Mark as synced"| A
    
    style A fill:#e1f5fe
    style B fill:#f3e5f5
    style C fill:#e8f5e8
    style D fill:#fff3e0
    style E fill:#fce4ec
```

---

## 🚀 Getting Started (The Easy Way)

### Step 1: Get the Code
```bash
git clone <your-repo-url>
cd outsmart_circuit_integration_production
pip install -r requirements.txt
```

### Step 2: Tell It Your Secrets
Create a `.env` file with your API credentials:
```env
OUTSMART_BASE_URL=https://your-outsmart-url.com
OUTSMART_BEARER=your_outsmart_api_token
CIRCUIT_API_KEY=your_circuit_api_key
REDIS_URL=redis://localhost:6379/0
```

### Step 3: Take It for a Test Drive
```bash
# Sync just today's new work orders, execute project with the following sequence:
1. python test_apis.py
2. python force_cache_update.py
3. python run_sync.py

# Sync everything that hasn't been synced yet (great for initial setup for debugging)
python run_sync.py all
```

### Step 4: Let It Run Itself (Production Mode)
Start the automation engines:
```bash
# In one terminal - this handles the actual work
celery -A app.celery_worker.app worker --loglevel=info

# In another terminal - this schedules the daily sync
celery -A app.celery_worker.app beat --loglevel=info
```

That's it! Now it runs every day at 6 AM automatically.

---

## 🔧 For the Technical Folks

**What's under the hood:**
- **Python 3.9+** because life's too short for old Python versions
- **httpx** for making API calls that actually work reliably
- **Celery** handling the background jobs and scheduling
- **Redis** keeping track of what needs to happen when
- **Smart retry logic** because APIs sometimes have bad days
- **Comprehensive logging** so you can debug anything that goes sideways

**Architecture decisions we made:**
- **Idempotent by design** - running it twice won't create chaos
- **Fail-safe syncing** - only successful operations get marked as complete
- **Modular structure** - easy to extend without breaking existing functionality
- **Production-ready logging** - every API call is recorded with timestamps

---

## 🎯 What This Means for Your Business

### Before This Integration
- ⏰ **Daily manual work** copying orders between systems
- 😰 **Risk of human error** in data entry
- 📊 **No visibility** into what was synced when
- 🚨 **Potential for duplicates** or missed deliveries
- ⚡ **Drivers getting suboptimal routes**

### After This Integration
- ☕ **Grab coffee while it syncs automatically**
- ✅ **Zero data entry errors**
- 📈 **Complete audit trail** of every sync
- 🛡️ **Bulletproof duplicate prevention**
- 🎯 **Drivers get optimized routes every day**

---

## ❓ Questions People Actually Ask

**"What happens if Circuit is down when it tries to sync?"**  
It waits and tries again later. Failed syncs don't get marked as complete, so nothing gets lost.

**"Can I control which drivers get assigned to which routes?"**  
Absolutely! The driver assignment logic is in one place and easy to customize. Want depot-specific assignments? Custom logic based on driver skills? Just a few lines of code to change.

**"How do I know if something went wrong?"**  
Check the logs in `app/logs/`. Every API call, every response, every decision is recorded with timestamps. You'll know exactly what happened and when.

**"Is this actually ready for production?"**  
We call it "stable beta" because it's been running reliably in production environments, but we're still actively improving it based on real user feedback. Translation: it works great, but we're not done making it even better.

**"What if I need to sync historical data?"**  
Run `python run_sync.py all` and it'll sync everything that hasn't been synced yet, regardless of date.

---

## 🌻 Getting Help

**Something not working right?** Open an issue and we'll figure it out together.

**Want a new feature?** Tell us what you need - we build based on real user requests.

**Need implementation help?** Reach out to your integration partner or the maintainer.

---

## 🎉 The Bottom Line

**This isn't just another API integration.** It's designed to actually solve the daily headache of managing deliveries across multiple systems.

**For your drivers:** They get better routes without asking for them.

**For your dispatchers:** They can focus on exceptions instead of data entry.

**For your business:** You get reliable, auditable delivery management that scales with you.

**For your sanity:** One less thing to worry about every morning.

---

<div align="center">

*Built by logistics people, for logistics people* 🚛❤️

**Because moving stuff shouldn't be this complicated.**

</div>


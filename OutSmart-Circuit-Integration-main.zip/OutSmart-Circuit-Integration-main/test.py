import httpx
from app.config import OUTSMART_BASE_URL, OUTSMART_BEARER

headers = {
    "Authorization": f"Bearer {OUTSMART_BEARER}",
    "Accept": "*/*"
}

url = f"{OUTSMART_BASE_URL}/GetWorkorders/?software_token=&update_status=false"

res = httpx.get(url, headers=headers)
print(f"[Status] {res.status_code}")
print(res.text[:1000])  # limit to first 1000 chars
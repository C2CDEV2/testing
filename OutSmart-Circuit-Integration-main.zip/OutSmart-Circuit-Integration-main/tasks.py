from celery import shared_task
from app.sync_jobs import sync_routes

@shared_task
def daily_route_sync():
    """Celery task to sync all new workorders from Outsmart to Circuit."""
    sync_routes()